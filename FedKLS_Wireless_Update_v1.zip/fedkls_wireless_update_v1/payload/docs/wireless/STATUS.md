# Current wireless status / next-chat checkpoint

**Release v1, 2026-11-09.** Implemented: numerical core, padded integer packet v2,
strict opt-in parsing, current-round prepare/query/grant lifecycle, client Context cache,
local and Flower/Ray adapters, dynamic byte/control/time/energy logs, completed-round
resume, six policy cases, study generator/two queues, terminal summaries/new plots,
and explicit wireless artifacts in lightweight handoffs.

Executed locally: numerical/protocol tests, synthetic CPU end-to-end cases, local
uninterrupted/resumed equivalence, actual MNIST CNN and CentralEvaluator on synthetic
images, generator invariance and lightweight export tests, legacy suite/24 endpoint
checks. Read VALIDATION.md for exact counts. None are a new MNIST/CIFAR performance run.

**Not yet executed:** real Flower1.29/Ray adapter on the user's environment, CUDA, real
dataset wireless training, long queues, or physical radio experiments. The supplied
real Flower test and Ray smoke are runtime gates, not claimed successful results.

**Not locked:** physical bandwidth/gains/PSD/noise, device preparation coefficients,
round deadline/control allowance, total modeled-time budget and experimental seeds for
wireless. `scenario_example.yaml` is an engineering illustration. The old learning
profiles are retained but do not supply these physical parameters.

Not implemented by design: AirComp, fixed-total-power bandwidth-dependent rate solver,
client scheduling, retransmissions, adaptive local compute, mid-round recovery, privacy
mechanism, certified finite-precision optimality, or arbitrary legacy-checkpoint import.
A future extension must state any departure from this contract explicitly.

Next action: install/verify, run CPU tests, run actual Flower/Ray smoke, approve a physical
scenario, then a separately named short dataset smoke before long comparative runs.
Preserve all finished legacy paper outputs and current plot command.
