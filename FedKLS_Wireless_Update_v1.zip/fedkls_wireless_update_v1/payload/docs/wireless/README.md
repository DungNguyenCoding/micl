# Wireless FedKLS v1 — implemented digital simulation path

**2026-11-09 · protocol `fedkls_wireless_integer_precision_v2`.** This directory
supersedes the earlier preimplementation review as the status authority. The supplied
proposal is preserved under [proposal](proposal/README.md); review material is under
[preimplementation](preimplementation/README.md).

## Implemented scope

The opt-in runner performs **PREPARE → scalar TAIL/PRICE requests → exact UPLOAD grant
→ packet validation/prior fill → RELEASE → aggregation/evaluation → commit**.
Every participating client trains the full model once per round with the existing trainer.
Prepared state survives ephemeral Flower client objects via `Context.state`; the local
backend uses an explicit client-owned memory store. Only scalar replies and granted
posterior packets are visible through the server interface.

Implemented policies: joint KL threshold allocation (Version B); joint counts with random
coordinates; equal-bandwidth maximal feasible counts (Version A); uniform feasible count;
dense FOLA; dense FedAvg. All use the same declared fixed-slot policy. Successful digital
transmission leaves raw float32 values unchanged. No AirComp, noisy weight perturbation,
client scheduling/dropout, adaptive local epochs, sparse downlink, quantization, error
feedback or new learning objective is added.

Read [IMPLEMENTATION.md](IMPLEMENTATION.md) for mechanism/adaptations,
[CONFIGURATION.md](CONFIGURATION.md) for fields and scenario decisions,
[RUNBOOK.md](RUNBOOK.md) for commands, [OUTPUTS.md](OUTPUTS.md) for results/resume,
[VALIDATION.md](VALIDATION.md) for actual tests, and [STATUS.md](STATUS.md) for open gates.

## Compatibility

`wireless` absent or disabled leaves the legacy serialized configuration/fingerprint
unchanged. Existing packets/byte-budget stopping/resume and plots remain on their original
path. Wireless uses exact counts directly, a new packet version, separate accounting and
`wireless_resume/`. Never resume a legacy checkpoint through the wireless controller.
Existing source docs before this release are under `../history/pre_wireless_v1/`.

## Runtime boundary

The local CPU backend and synthetic integrations were executed. The real Flower/Ray
adapter and its tests are supplied but could not be executed in the authoring environment.
Do not call a skipped Flower test a pass. Run the target-environment gates before
launching dataset studies. No new MNIST/CIFAR wireless accuracy result is claimed.
