# Validation actually performed — wireless v1

Authoring check date: 2026-11-09. See repository-root `validation/wireless/` for logs.

| Check | Observed result |
|---|---|
| Full available legacy + wireless pytest | **186 passed, 6 skipped** |
| Wireless-only tests within the suite | 58 passed; real-Flower module skipped |
| Original YAML load / serialized config / legacy fingerprint | **891 / 891 identical**, no original config edits |
| Primary-paper CSV endpoints and exact byte totals | **24 / 24 pass** |
| Synthetic CPU complete multi-phase CLI | Six policies, three rounds each; original trainers |
| Clean evaluated-round resume | All six policies' local interrupted-at-commit versus uninterrupted state/bytes match |
| Current MNIST CNN + CentralEvaluator | Synthetic 28x28 image test; real runner + evaluated resume pass |
| Integer oracle / feasibility tests | Tiny exhaustive spaces, ties, zero tails, padded sizes, dense switch, finite limits |
| Dynamic reporting / export | Exact-count packet checks, malformed-cost rejection, hash-checked explicit wireless-only ZIP |
| Study generation | Both locked profiles preserve all inherited data/model/runtime/FOLA and training fields except explicit total rounds |
| Source Python 3.10 grammar | 142 active Python files parse; not Python 3.10 runtime certification |
| New queue Bash syntax | `bash -n` passes |
| Overlay installer | 9 checks pass on temporary repositories: preview, confirmation, backup/apply/verify, idempotence, prior-review compatibility and refusal guards |
| Original trainers/models/partition/reducer/legacy protocol/dependencies/primary files | Byte-preserved; exact record in baseline_preservation.json |

The six skips are three missing Bayesian-Torch tests, the original Flower smoke, the
original sparse Flower integration module, and the new wireless real-Flower module.
**A skipped module does not validate its contained scenarios.** No fake Flower package
was used as a substitute. No actual Flower/Ray/CUDA call was executed in this environment.

Authoring runtime: Python3.13.5, Torch2.10.0+cpu, Torchvision0.25.0+cpu, NumPy2.3.5,
PyYAML6.0.3, pytest9.0.2. Flower, Ray and Bayesian-Torch were absent. Target environment
remains the supplied Python3.10/Flower1.29/Bayesian-Torch0.5 working CUDA stack.
No dependency manifest was modified to fit the authoring environment.

## What synthetic checks do not establish

No real-dataset wireless training, generalization advantage, statistically significant
accuracy improvement, physically measured latency/energy, true radio framing cost,
universal integer optimum, power-loss atomicity or target-GPU performance was established.
Dense cases in the synthetic CLI use a higher bandwidth solely to cover the dense code;
they are not matched-scenario scientific comparisons. Numerical dual gaps are diagnostics.

## Target-environment gates

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" -m pytest -q tests/wireless
"$PY" -m pytest -q
"$PY" -m pytest -q tests/wireless/test_flower.py
CUDA_VISIBLE_DEVICES="" "$PY" scripts/smoke_wireless_flower.py \
  --output-dir "outputs/smoke_wireless_ray_$(date +%Y%m%d_%H%M%S)" --rounds 2
"$PY" docs/tools/export_handoff.py --check
```

Only after those runtime checks should a separately named two-round real dataset/CUDA
smoke be launched with a reviewed scenario. Record the actual output, environment,
file versions and any failures in this document; do not overwrite historical evidence.
