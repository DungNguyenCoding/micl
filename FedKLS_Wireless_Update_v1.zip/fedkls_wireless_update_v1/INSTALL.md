# Install the wireless v1 overlay

Extract this package BESIDE bayesfl, not inside it. Stop training/source writers first.
The installer only writes its explicit source/docs/test/tool allowlist. No output,
dataset, partition, dependency, Git-ignore or existing plot/queue file is installed.
Local changes outside accepted uploaded/review versions cause a refusal; no force mode.

```bash
cd ~/DungNDH/micl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
"$PY" fedkls_wireless_update_v1/install_wireless.py --root "$PWD/bayesfl" --preview
"$PY" fedkls_wireless_update_v1/install_wireless.py --root "$PWD/bayesfl" --apply --confirm INSTALL_FEDKLS_WIRELESS_V1
"$PY" fedkls_wireless_update_v1/install_wireless.py --root "$PWD/bayesfl" --verify
```

Apply saves original files and an exact INSTALL_RECEIPT.json under the sibling
bayesfl_wireless_backup_<timestamp> directory. Keep that backup. Writes are atomically
replaced per file; the entire installation is not a power-loss-atomic transaction.
An interrupted install's receipt records what was written. Re-running against already
installed identical files is safe, but do not force a conflict or delete the backup.

After verification, read bayesfl/docs/wireless/RUNBOOK.md and VALIDATION.md. Run
CPU tests, target Flower/Ray gates and a short dataset smoke before long runs.
The example physical scenario is not a locked paper experiment.

The companion full repository ZIP is for a SEPARATE reference extraction. Do not
force-extract it over a live repository because it also preserves the uploaded
legacy output snapshot. The smaller overlay is the recommended live installation.
