# BayesFL documentation and handoff package — 2026-10-26

This package updates documentation only. It does not replace the repository or install the older source archive. Keep this extracted directory beside `bayesfl/`; do not unzip `payload/` directly over the repository.

## 1. Put the ZIP beside the repository and extract

Save `bayesfl_docs_handoff_20261026.zip` in `~/DungNDH/micl/`, then:

```bash
cd ~/DungNDH/micl || exit 1
unzip -n bayesfl_docs_handoff_20261026.zip
```

The ZIP contains `bayesfl_docs_handoff_20261026/` with `install_docs.py`, `MANIFEST.json`, this file, and `payload/`.

## 2. Preview (no repository writes)

```bash
cd ~/DungNDH/micl || exit 1
/home/micl/anaconda3/envs/dungndh/bin/python \
  bayesfl_docs_handoff_20261026/install_docs.py \
  --root "$PWD/bayesfl" --preview
```

Every path must be a permitted root documentation file or under `docs/`. Original uploaded Markdown files are the only recognized previous versions for replacement (CRLF/LF-only differences are accepted). An unknown newer/conflicting file stops installation rather than silently overwriting it. Matching already-installed files are skipped.

## 3. Apply with backups

```bash
cd ~/DungNDH/micl || exit 1
/home/micl/anaconda3/envs/dungndh/bin/python \
  bayesfl_docs_handoff_20261026/install_docs.py \
  --root "$PWD/bayesfl" \
  --apply --confirm UPDATE_BAYESFL_DOCS
```

Existing replaced docs are copied and hash-checked before the first replacement into:

```text
~/DungNDH/micl/bayesfl_docs_backup_<timestamp>/
    previous/<original-relative-path>
    INSTALL_RECEIPT.json
```

The receipt lists all planned and actually written files. Newly added docs are not treated as old originals. If an operation stops partway, preserve the receipt and backup and inspect before another write. Do not use `rm -rf` or a blind full-directory copy as rollback. To undo a particular replaced document, use the exact `previous/` file and verify its hash; removing newly added documentation is a separate reviewed action. This installer has no deletion or training functionality.

The installer checks existing src/scripts/tests and root dependency/provenance/.gitignore hashes before and after apply. Stop concurrent code editing during installation; unrelated concurrent changes can cause its guard to stop. Outputs/partitions/datasets are not install targets. It is not a whole-filesystem transaction.

## 4. Verify installation

```bash
cd ~/DungNDH/micl || exit 1
/home/micl/anaconda3/envs/dungndh/bin/python \
  bayesfl_docs_handoff_20261026/install_docs.py \
  --root "$PWD/bayesfl" --verify
```

Verification confirms installed documentation hashes, not the training algorithm. Read `bayesfl/docs/START_HERE.md` and `bayesfl/docs/CHAT_HANDOFF.md`.

## 5. Optional: print current raw results and capture live source for a new chat

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
/home/micl/anaconda3/envs/dungndh/bin/python \
  docs/tools/export_handoff.py --check

/home/micl/anaconda3/envs/dungndh/bin/python \
  docs/tools/export_handoff.py --export
```

Check mode prints raw endpoint results only. Export mode checks them and creates a new `bayesfl_LIVE_HANDOFF_<timestamp>.zip` beside the repository, without altering existing files. It requires actual primary metrics and saved resolved configs. Stop writers before capturing a consistent snapshot; per-file stability is checked, not full-tree atomicity.

Export includes selected current code, scripts/configs/queues, tests, docs and 24 primary metric trajectories/config metadata. It excludes weights, resume arrays, transfer ledgers, raw datasets, partition NPZs, logs and .git. It is not a complete/resumable training backup. Review it before external sharing.

The docs correctly leave CIFAR R150 endpoint accuracies unspecified until read from the real CSVs. The helper is intended to capture that missing evidence, not estimate it. Expected source accuracy units are fractions; use the explicit percent option only for verified percent-valued histories.

## What is intentionally unchanged

- `src/`, existing `scripts/`, all simulation YAMLs/queues, `tests/`, `outputs/`, `plots/`, partitions and datasets.
- `pyproject.toml`, `requirements.txt` and `.gitignore`.
- Root `CHANGE_MANIFEST.json` and `PACKAGE_MANIFEST.txt`, which remain historical release provenance.

All 14 supplied original files are preserved exactly under `payload/docs/history/pre_refresh_20261026/`. Old assumptions are not silently rewritten in those historical copies. `DOCS_UPDATE_MANIFEST.json` is a separate documentation-only manifest.

## Start a new chat

Attach `bayesfl/docs/CHAT_HANDOFF.md` and this documentation ZIP. For code changes or current result analysis, also attach the lightweight live export. Say:

> Continue the BayesFL/FedKLS project from these documents. Read CHAT_HANDOFF, COMMAND_RULES, LOCKED_EXPERIMENTS, EXPERIMENT_REGISTRY and EVIDENCE_AND_GAPS first. Preserve selected results, source settings and archive state; do not retune or rerun completed work unless requested. Use the live source/config/metric snapshot for implementation-dependent claims. My next task is: ...

If only one document is practical, use the separately delivered `BayesFL_New_Chat_Handoff_20261026.md`; it is the same text as `docs/CHAT_HANDOFF.md`. It is self-contained for decisions and primary paths, but cannot replace actual code/metrics for implementation work.
