#!/usr/bin/env python3
"""Install the BayesFL documentation bundle only; default is read-only preview.

No training/runtime/config/queue/output/dependency/Git edits. Existing replaced
files are backed up beside the repository. Unknown conflicting docs abort.
Standard library only. Keep this installer in the extracted bundle, not scripts/.
"""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parent
PAYLOAD = BUNDLE / 'payload'
MANIFEST = BUNDLE / 'MANIFEST.json'
ROOT_ALLOWLIST = {'README.md', 'AGENTS.md', 'SPARSE_README.md', 'IMPLEMENTATION_REPORT.md',
                  'VALIDATION.md', 'VALIDATION_SPARSE.md', 'DOCS_UPDATE_MANIFEST.json'}


def fail(msg: str) -> None:
    raise RuntimeError(msg)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalized_digest(data: bytes) -> str:
    return digest(data.replace(b'\r\n', b'\n'))


def validate_rel(rel: str) -> None:
    p = PurePosixPath(rel)
    if p.is_absolute() or '..' in p.parts or '\\' in rel or str(p) != rel:
        fail('Unsafe payload path: '+rel)
    if rel not in ROOT_ALLOWLIST and not rel.startswith('docs/'):
        fail('Non-documentation destination refused: '+rel)
    if rel.endswith('.py') and rel != 'docs/tools/export_handoff.py':
        fail('Unexpected executable payload: '+rel)


def destination(root: Path, rel: str) -> Path:
    validate_rel(rel)
    cur = root
    for part in PurePosixPath(rel).parts:
        cur = cur / part
        if cur.is_symlink():
            fail('Symbolic destination or parent refused: '+str(cur))
    return cur


def load_manifest() -> dict:
    m = json.loads(MANIFEST.read_text(encoding='utf-8'))
    seen = set()
    for rec in m['files']:
        rel = rec['path'];validate_rel(rel)
        if rel in seen:
            fail('Duplicate payload path: '+rel)
        seen.add(rel)
        p = PAYLOAD / rel
        if p.is_symlink() or not p.is_file():
            fail('Payload missing/not regular: '+rel)
        data = p.read_bytes()
        if len(data) != rec['bytes'] or digest(data) != rec['sha256']:
            fail('Payload checksum mismatch: '+rel)
    actual = {p.relative_to(PAYLOAD).as_posix() for p in PAYLOAD.rglob('*') if p.is_file()}
    if actual != seen:
        fail('Payload/manifest file list mismatch')
    return m


def inspect(root: Path, m: dict, verify: bool = False) -> list[dict]:
    if not (root/'src/bayesfl').is_dir() or not (root/'scripts').is_dir():
        fail(f'Not the expected repository root: {root}')
    plan = []
    problems = []
    for rec in m['files']:
        path = destination(root, rec['path'])
        state = 'ADD'
        before = None
        if path.exists():
            if not path.is_file():
                problems.append('Destination is not a file: '+rec['path']);continue
            old = path.read_bytes();before=digest(old)
            if before == rec['sha256']:
                state = 'UNCHANGED'
            elif before == rec.get('expected_previous_sha256') or normalized_digest(old) == rec.get('expected_previous_lf_sha256'):
                state = 'REPLACE_BACKED_UP'
            else:
                problems.append('Existing document differs from supplied original; preserve/reconcile it first: '+rec['path'])
                continue
        if verify and state != 'UNCHANGED':
            problems.append('Installed file not at package version: '+rec['path']);continue
        plan.append({**rec, 'state':state, 'live_before_sha256':before})
    if problems:
        fail('\n'.join(problems))
    return plan


def runtime_hashes(root: Path) -> dict:
    """Read-only guard for existing code/configs/tests and root environment files."""
    hashes = {}
    for group in ('src','scripts','tests'):
        base=root/group
        if not base.exists():continue
        for current, dirs, names in os.walk(base, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in {'__pycache__','.pytest_cache','.git'})
            for d in list(dirs):
                p=Path(current)/d
                if p.is_symlink():
                    hashes[p.relative_to(root).as_posix()]={'link':os.readlink(p)}
                    dirs.remove(d)
            for name in sorted(names):
                p=Path(current)/name
                if p.suffix=='.pyc':continue
                rel=p.relative_to(root).as_posix()
                hashes[rel]={'link':os.readlink(p)} if p.is_symlink() else {'sha256':digest(p.read_bytes())}
    for name in ('pyproject.toml','requirements.txt','CHANGE_MANIFEST.json','PACKAGE_MANIFEST.txt','.gitignore'):
        p=root/name
        if p.is_symlink():hashes[name]={'link':os.readlink(p)}
        elif p.is_file():hashes[name]={'sha256':digest(p.read_bytes())}
    return hashes


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.bayesfl-docs-', dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        # Documentation remains readable by ordinary collaborators.
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def apply(root: Path, m: dict, plan: list[dict]) -> Path | None:
    todo=[r for r in plan if r['state']!='UNCHANGED']
    if not todo:
        print('PASS: Already installed; no files changed.');return None
    guard=runtime_hashes(root)
    stamp=datetime.now().astimezone().strftime('%Y%m%d_%H%M%S_%f')
    backup=root.parent/f'bayesfl_docs_backup_{stamp}'
    backup.mkdir(exist_ok=False)
    # Back up every replacement and the manifest BEFORE the first overwrite.
    for rec in todo:
        dest=destination(root,rec['path'])
        if rec['live_before_sha256'] is not None:
            data=dest.read_bytes()
            if digest(data)!=rec['live_before_sha256']:
                fail('File changed after preview: '+rec['path'])
            old=backup/'previous'/rec['path'];old.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dest,old)
            if digest(old.read_bytes())!=digest(data):fail('Backup hash mismatch: '+rec['path'])
        elif dest.exists():
            fail('New destination appeared during install: '+rec['path'])
    receipt={'repository':str(root),'created_at':datetime.now().astimezone().isoformat(),
             'package':'bayesfl_docs_handoff_20261026','backup':str(backup),
             'planned':todo,'written':[], 'runtime_hashes_before':guard,'status':'prepared'}
    def save_receipt():
        atomic_write(backup/'INSTALL_RECEIPT.json',(json.dumps(receipt,indent=2)+'\n').encode())
    save_receipt()
    try:
        for rec in todo:
            dest=destination(root,rec['path'])
            if rec['live_before_sha256'] is None:
                if dest.exists():fail('Refusing new-file overwrite: '+rec['path'])
            elif digest(dest.read_bytes())!=rec['live_before_sha256']:
                fail('Concurrent documentation edit: '+rec['path'])
            atomic_write(dest,(PAYLOAD/rec['path']).read_bytes())
            receipt['written'].append(rec['path']);save_receipt()
        inspect(root,m,verify=True)
        after=runtime_hashes(root)
        if after!=guard:
            fail('Runtime/code guard changed during installation. Stop writers and inspect receipt; no automatic deletion/rollback attempted.')
        receipt['status']='verified';receipt['runtime_guard_unchanged']=True;save_receipt()
    except Exception as exc:
        receipt['status']='stopped';receipt['error']=str(exc);save_receipt()
        print('Installation stopped; backups and exact written-file list:',backup,file=sys.stderr)
        raise
    print(f'\nPASS: Documentation installed and verified.\nBackup: {backup}')
    print('Existing src/scripts/tests/dependency/Git-ignore/provenance files checked unchanged.')
    print('Outputs, partitions, datasets, figure scripts and existing queues were not installation targets.')
    return backup


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    mode=p.add_mutually_exclusive_group()
    mode.add_argument('--preview',action='store_true')
    mode.add_argument('--apply',action='store_true')
    mode.add_argument('--verify',action='store_true')
    p.add_argument('--confirm',default='')
    args=p.parse_args();root=args.root.expanduser().resolve()
    if args.apply and args.confirm!='UPDATE_BAYESFL_DOCS':
        fail('Apply requires --confirm UPDATE_BAYESFL_DOCS')
    m=load_manifest();plan=inspect(root,m,verify=args.verify)
    for rec in plan:print(f'{rec["state"]:<20} {rec["path"]}')
    print('\nFiles in package:',len(plan))
    print('New:',sum(r['state']=='ADD' for r in plan),'Replace with backup:',sum(r['state']=='REPLACE_BACKED_UP' for r in plan),'Already identical:',sum(r['state']=='UNCHANGED' for r in plan))
    if args.verify:print('PASS: Installed documentation matches the package hashes.')
    elif args.apply:apply(root,m,plan)
    else:print('PASS: PREVIEW ONLY; no files or directories created in the repository.')
    return 0


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except (OSError,ValueError,RuntimeError,KeyError) as exc:
        print('ERROR:',exc,file=sys.stderr)
        raise SystemExit(1)
