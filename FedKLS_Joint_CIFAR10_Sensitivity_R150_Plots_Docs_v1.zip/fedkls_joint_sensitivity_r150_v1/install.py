#!/usr/bin/env python3
"""Safely install joint CIFAR R150 sensitivity plotting code + research docs.

- Adds only new files; refuses collisions with differing bytes.
- Appends idempotent, tagged references to existing documentation.
- Backs up changed canonical documents outside the repository.
- Does not modify training source/configs/experiment outputs/locked registry.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"
TOKEN = "APPLY_JOINT_CIFAR_SENSITIVITY_R150_V1"
MARK_START = "<!-- BEGIN FEDKLS_JOINT_SENSITIVITY_R150_V1 -->"
MARK_END = "<!-- END FEDKLS_JOINT_SENSITIVITY_R150_V1 -->"
SUMMARY = (
    "## Joint CIFAR-10 wireless sensitivity R150 — verified 2026-11-12\n\n"
    "- Main method: **joint-KL** bandwidth/retention; 20 clients, CIFAR BasicCNN, seed 0, fixed channel gains, 150 rounds. "
    "The original joint reference (Bmax=1 MHz, U=58.973 s) reached **52.63%**. Six additional fixed-channel R150 cases "
    "passed engineering record-integrity audits.\n"
    "- **U sweep** at Bmax=1 MHz: U=48.973 s → 50.25%; U=38.973 s → 52.47%; U=28.973 s → 43.43%.\n"
    "- **B sweep** at U=58.973 s: Bmax=0.55 MHz → 47.29%; 0.75 MHz → 52.53%; 0.95 MHz → 54.01%.\n"
    "- All seven source-audit ZIPs independently matched their **161 SHA-256 evidence hashes**. "
    "Configurations match except run_name, uplink bandwidth and round target. "
    "The R150 learning outcomes are **non-monotone**, and the two harshest cases show pronounced learning oscillations.\n"
    "- Price-search `price_tolerance` in U150 **21/150** and B0550 **27/150** rounds. "
    "This is a solver stopping caution, not an audit failure; global integer optimality is not certified.\n"
    "- This is a **single-seed engineering simulation**. The reference scenario is `EXAMPLE_NOT_LOCKED`, "
    "not physically calibrated. Shorter U also means shorter modeled round duration; compare both accuracy vs rounds and modeled time.\n\n"
    "**Full verified audit and results:** `docs/wireless/JOINT_CIFAR10_SENSITIVITY_R150_20261112.md`  \n"
    "**Reproducible plotting guide:** `docs/wireless/JOINT_SENSITIVITY_PLOTS_RUNBOOK_v1.md`  \n"
    "**Plot script:** `scripts/plot_joint_cifar_sensitivity_v1.py` (generates 4 side-by-side PNG/PDF figures + CSVs without retraining).\n"
)
TARGETS = (
    "docs/CHAT_HANDOFF.md",
    "docs/wireless/STATUS.md",
    "docs/wireless/VALIDATION.md",
    "docs/wireless/README.md",
    "docs/RUN_REGISTRY.md",  # optional if present
)
REQUIRED_TARGETS = set(TARGETS[:4])


def digest(b): return hashlib.sha256(b).hexdigest()

def eol(b):
    return "\r\n" if b.count(b"\r\n") > 0 and b.count(b"\r\n") >= b.count(b"\n") * .5 else "\n"

def tagged_block(): return MARK_START + "\n" + SUMMARY.rstrip() + "\n" + MARK_END + "\n"

def normalize(s): return s.replace("\r\n", "\n")

def read_safe(p: Path) -> bytes:
    if p.is_symlink():
        raise ValueError(f"Refusing symlink: {p}")
    return p.read_bytes()


def plans(root: Path, manifest: dict):
    results=[]
    for rel, expected in manifest['files'].items():
        src=PAYLOAD/rel
        if not src.is_file() or digest(read_safe(src))!=expected:
            raise ValueError(f"Installer package corrupted: {src}")
        dst=root/rel
        if dst.is_symlink(): raise ValueError(f"Refusing symlink destination {dst}")
        if dst.exists():
            if not dst.is_file() or digest(read_safe(dst))!=expected:
                raise ValueError(f"Existing file differs: {dst}; cannot overwrite")
            results.append(('IDENTICAL',rel))
        else:
            results.append(('ADD',rel))
    block=tagged_block()
    for rel in TARGETS:
        dst=root/rel
        if not dst.exists():
            if rel in REQUIRED_TARGETS:
                raise ValueError(f"Required canonical document missing: {dst}")
            results.append(('OPTIONAL_MISSING',rel))
            continue
        b=read_safe(dst)
        try:
            s=b.decode('utf-8')
        except UnicodeDecodeError:
            raise ValueError(f"Cannot safely edit non-UTF8 doc: {dst}")
        ss=normalize(s)
        have_start=MARK_START in ss
        have_end=MARK_END in ss
        if have_start != have_end or ss.count(MARK_START)>1 or ss.count(MARK_END)>1:
            raise ValueError(f"Conflicting/incomplete documentation tag: {dst}")
        if have_start:
            frag=ss[ss.index(MARK_START):ss.index(MARK_END)+len(MARK_END)]
            if frag!=block.rstrip():
                raise ValueError(f"Existing tagged documentation differs: {dst}")
            results.append(('ALREADY_LINKED',rel))
        else:
            results.append(('APPEND_WITH_BACKUP',rel))
    return results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',required=True,type=Path,help='Live BayesFL root')
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--preview',action='store_true')
    g.add_argument('--apply',action='store_true')
    g.add_argument('--verify',action='store_true')
    p.add_argument('--confirm',default='')
    args=p.parse_args()
    root=args.root.expanduser().resolve(strict=True)
    if not (root/'src/bayesfl').is_dir() or not (root/'scripts/configs/wireless').is_dir():
        raise ValueError(f"Not a BayesFL repository: {root}")
    manifest=json.loads((HERE/'MANIFEST.json').read_text())
    rows=plans(root,manifest)
    for action,rel in rows: print(f'{action:<21} {rel}')
    print('Plan:',{k:sum(1 for a,_ in rows if a==k) for k in sorted(set(a for a,_ in rows))})
    if args.preview:
        print('PASS: PREVIEW ONLY, no files changed')
        return
    if args.verify:
        if any(a in {'ADD','APPEND_WITH_BACKUP'} for a,_ in rows):
            raise ValueError('Verification incomplete: some files/links not installed')
        print('PASS: FIGURE SCRIPT AND CANONICAL DOCUMENTATION VERIFIED')
        return
    if args.confirm!=TOKEN:
        raise ValueError(f'Explicit confirmation required: --confirm {TOKEN}')
    changes=[rel for action,rel in rows if action=='APPEND_WITH_BACKUP']
    backup=None
    if changes:
        stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        backup=root.parent/f'bayesfl_joint_sensitivity_docs_backup_{stamp}'
        for rel in changes:
            (backup/rel).parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(root/rel,backup/rel)
    for action,rel in rows:
        if action=='ADD':
            dst=root/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            # exclusive creation: never replace files that appeared after preview
            with dst.open('xb') as f: f.write((PAYLOAD/rel).read_bytes())
        elif action=='APPEND_WITH_BACKUP':
            dst=root/rel
            prior=read_safe(dst)
            nl=eol(prior)
            prefix=b'' if prior.endswith(b'\n') else nl.encode()
            extra=("\n"+tagged_block()).replace('\n',nl).encode('utf8')
            with dst.open('ab') as f: f.write(prefix+extra)
    results=plans(root,manifest)
    if any(a in {'ADD','APPEND_WITH_BACKUP'} for a,_ in results):
        raise ValueError('Post-install verification failed; backups are preserved')
    print('PASS: Joint R150 plot script, report and canonical handoff links installed')
    if backup: print('Backup of prior docs:',backup)
    print('No source training code, experiment config, checkpoint, output or locked registry modified')

if __name__=='__main__':
    try: main()
    except (ValueError,OSError,KeyError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        raise SystemExit(2)
