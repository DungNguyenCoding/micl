# FedKLS Joint CIFAR-10 R150 sensitivity: audited result + side-by-side plot script

**Version:** 1 (2026-11-12). Additive release. **No retraining.**

## Contents

- `payload/scripts/plot_joint_cifar_sensitivity_v1.py`: standalone, read-only plotter; loads the original seven R150 joint run CSVs through study manifests. Four two-column figures as PNG+PDF, endpoint and trajectory CSVs, source provenance.
- `payload/docs/wireless/JOINT_CIFAR10_SENSITIVITY_R150_20261112.md`: complete audited outcomes, evidence integrity, solver warnings, interpretation.
- `payload/docs/wireless/JOINT_SENSITIVITY_PLOTS_RUNBOOK_v1.md`: copy/paste remote commands, plot definitions.
- `install.py`: safe preview → append-only docs backups → verify. Refuses to overwrite an existing different script or document.
- `preview_figures/generated/`: reference plots and numeric summaries generated **from the seven uploaded audited ZIPs**. (Not installed into the live repo.)

## Run on Linux server

Place `FedKLS_Joint_CIFAR10_Sensitivity_R150_Plots_Docs_v1.zip` at `~/DungNDH/micl/`:

```bash
cd ~/DungNDH/micl || exit 1
unzip -n FedKLS_Joint_CIFAR10_Sensitivity_R150_Plots_Docs_v1.zip
PY=/home/micl/anaconda3/envs/dungndh/bin/python
"$PY" fedkls_joint_sensitivity_r150_v1/install.py --root "$PWD/bayesfl" --preview
"$PY" fedkls_joint_sensitivity_r150_v1/install.py --root "$PWD/bayesfl" --apply --confirm APPLY_JOINT_CIFAR_SENSITIVITY_R150_V1
"$PY" fedkls_joint_sensitivity_r150_v1/install.py --root "$PWD/bayesfl" --verify

cd ~/DungNDH/micl/bayesfl || exit 1
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" scripts/plot_joint_cifar_sensitivity_v1.py --root "$PWD" --check-only
OUT="plots/wireless/joint_cifar_sensitivity_r150_$(date +%Y%m%d_%H%M%S)"
"$PY" scripts/plot_joint_cifar_sensitivity_v1.py --root "$PWD" --output-dir "$OUT"
echo "PLOTS: $PWD/$OUT"
```

The plotting script does not edit source runs or checkpoints. The installer backs up and appends tagged, idempotent handoff links to existing docs; it never touches training code or experiment configuration. The plotter refuses an existing output directory.

## Reproduce offline from audited ZIPs

With all seven `bayesfl_joint_R150_audit_*.zip` files in one directory:

```bash
python payload/scripts/plot_joint_cifar_sensitivity_v1.py --audit-dir /path/to/zips --output-dir /path/to/new/output
```

Expected final values: **52.63% reference**, **50.25 / 52.47 / 43.43%** for the U sweep, and **47.29 / 52.53 / 54.01%** for the B sweep. Solver `price_tolerance` counts: **0 / 2 / 3 / 21 / 27 / 4 / 2** in reference/U170/U160/U150/B0550/B0750/B0950 order.
