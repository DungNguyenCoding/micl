#!/usr/bin/env python3
"""Safely register three additional MNIST architectures in an existing BayesFL repo.

This installer changes ONLY:
  src/bayesfl/models/mnist_mlp.py       (append two classes)
  src/bayesfl/models/mnist_cnn.py       (new file)
  src/bayesfl/models/factory.py         (register new classes)
  src/bayesfl/config.py                 (permit new model identifiers)
  tests/test_mnist_model_candidates.py  (new tests)

It does not edit any optimization, FOLA, Bayesian, aggregation,
posterior, partition, or communication code.

Usage:
  python install_three_mnist_models.py --repo ~/DungNDH/micl/bayesfl --check
  python install_three_mnist_models.py --repo ~/DungNDH/micl/bayesfl

Extract the supplied ZIP first; this installer expects the sibling
'full_modified_files' directory containing the full implementation.
"""

from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "full_modified_files"


def source(path: str) -> str:
    file = PAYLOAD / path
    if not file.is_file():
        raise FileNotFoundError(f"Patch bundle is incomplete: {file}")
    return file.read_text(encoding="utf-8").replace("\r\n", "\n")


def original(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    eol = "\r\n" if b"\r\n" in raw else "\n"
    return raw.decode("utf-8").replace("\r\n", "\n"), eol


def replace_once(text: str, old: str, new: str, path: str) -> str:
    if text.count(new) == 1:
        return text  # Already installed (new contains old as a prefix in some cases).
    if text.count(old) != 1:
        raise RuntimeError(
            f"Source has an unexpected layout in {path}; refusing to overwrite it. "
            "Please inspect this file and apply the corresponding full code manually."
        )
    return text.replace(old, new)


def plan(repo: Path) -> tuple[dict[str, str], dict[str, str]]:
    edits: dict[str, str] = {}
    line_endings: dict[str, str] = {}

    path = "src/bayesfl/models/mnist_mlp.py"
    old, eol = original(repo / path)
    full = source(path)
    start = "\n\nclass MNISTMLP200x2(nn.Module):\n"
    if full.count(start) != 1:
        raise RuntimeError("Malformed bundled MLP code")
    suffix = full[full.index(start):]
    present = ("class MNISTMLP200x2(" in old, "class MNISTMLP256x3(" in old)
    if present == (False, False):
        edits[path] = old.rstrip("\n") + suffix
    elif present != (True, True):
        raise RuntimeError(f"Only one new MLP exists in {path}; refusing partial installation")
    line_endings[path] = eol

    path = "src/bayesfl/models/factory.py"
    old, eol = original(repo / path)
    new = replace_once(
        old,
        "from .mnist_mlp import MNISTMLP, MNISTMLP256x5",
        "from .mnist_mlp import MNISTMLP, MNISTMLP256x5, MNISTMLP200x2, MNISTMLP256x3\n"
        "from .mnist_cnn import MNISTCompactCNN",
        path,
    )
    needle = ('        if cfg.model.name == "mlp_784_256x5_10":\n'
              '            return MNISTMLP256x5(**kwargs)')
    extended = needle + '''\n        if cfg.model.name == "mlp_784_200_200_10":
            return MNISTMLP200x2(**kwargs)
        if cfg.model.name == "mnist_cnn_16_32_128":
            return MNISTCompactCNN(**kwargs)
        if cfg.model.name == "mlp_784_256x3_10":
            return MNISTMLP256x3(**kwargs)'''
    new = replace_once(new, needle, extended, path)
    if new != old:
        edits[path] = new
    line_endings[path] = eol

    path = "src/bayesfl/config.py"
    old, eol = original(repo / path)
    needle = '''        if self.data.dataset == "mnist" and self.model.name not in {
            "mlp_784_500_300_10",
            "mlp_784_256x5_10",
        }:
            raise ValueError(
                "MNIST model.name must be mlp_784_500_300_10 or mlp_784_256x5_10"
            )'''
    extended = '''        if self.data.dataset == "mnist" and self.model.name not in {
            "mlp_784_500_300_10",
            "mlp_784_256x5_10",
            "mlp_784_200_200_10",
            "mnist_cnn_16_32_128",
            "mlp_784_256x3_10",
        }:
            raise ValueError(
                "MNIST model.name must be one of: "
                "mlp_784_500_300_10, mlp_784_256x5_10, "
                "mlp_784_200_200_10, mnist_cnn_16_32_128, "
                "mlp_784_256x3_10"
            )'''
    new = replace_once(old, needle, extended, path)
    if new != old:
        edits[path] = new
    line_endings[path] = eol

    for path in (
        "src/bayesfl/models/mnist_cnn.py",
        "tests/test_mnist_model_candidates.py",
    ):
        proposed = source(path)
        existing = repo / path
        if not existing.exists():
            edits[path] = proposed
            line_endings[path] = "\n"
        else:
            current, eol = original(existing)
            if current != proposed:
                raise RuntimeError(f"File already exists with different contents: {existing}")
            line_endings[path] = eol

    return edits, line_endings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd(),
                        help="Root of your BayesFL repository (default: current directory)")
    parser.add_argument("--check", action="store_true",
                        help="Check whether installation is possible; do not change files")
    args = parser.parse_args()
    repo = args.repo.expanduser().resolve()
    marker = repo / "src/bayesfl/models/factory.py"
    if not marker.is_file():
        parser.error(f"Not a BayesFL repository: missing {marker}")
    if not PAYLOAD.is_dir():
        parser.error(f"Missing patch sources: {PAYLOAD}")

    try:
        edits, eol = plan(repo)
    except (OSError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(f"Repository: {repo}")
    print(f"Would change: {len(edits)} files")
    for path in sorted(edits):
        print("  " + path)
    if args.check:
        print("PASS: dry run; nothing changed")
        return 0
    if not edits:
        print("PASS: already installed; no changes")
        return 0

    # Prepare backups for existing source files (including original EOLs).
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_root = repo / "backups/three_mnist_models" / stamp
    for path in edits:
        existing = repo / path
        if existing.exists():
            backup = backup_root / path
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(existing, backup)

    for path, new_text in edits.items():
        target = repo / path
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = new_text.replace("\n", eol[path]).encode("utf-8")
        temp = target.with_name(target.name + ".three_models_tmp")
        temp.write_bytes(payload)
        temp.replace(target)

    print(f"Original source backups: {backup_root}")
    print("PASS: installation complete")
    print("Next: PYTHONPATH=\"$PWD/src\" python -m pytest -q tests/test_mnist_model_candidates.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
