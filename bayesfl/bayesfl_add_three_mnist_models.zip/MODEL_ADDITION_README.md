# Add three candidate MNIST architectures to the current BayesFL repository

The bundle is based on the uploaded `bayesfl.zip` snapshot. It makes no
changes to the FOLA posterior update, prior iteration, empirical Fisher,
Gaussian-product aggregation, FedAvg, data partitioning, or communication ledger.

## New identifiers

| Model | Config `model.name` | Parameter count |
|---|---|---:|
| MLP 784-200-200-10 | `mlp_784_200_200_10` | 199,210 |
| CNN: Conv16, Conv32, FC128, FC10 | `mnist_cnn_16_32_128` | 80,202 |
| MLP 784-256-256-256-10 | `mlp_784_256x3_10` | 335,114 |

The compact CNN uses 5x5 unpadded convolutions, 2x2 max-pooling,
ReLU activations, and 512->128->10 fully-connected layers. No dropout,
batch normalization, or additional stochastic state. All outputs are raw logits.

## Install on the Linux experiment server

First extract the patch ZIP **outside** the existing BayesFL repository. For example:

```bash
mkdir -p /tmp/bayesfl_three_models
unzip bayesfl_add_three_mnist_models.zip -d /tmp/bayesfl_three_models
cd ~/DungNDH/micl/bayesfl

python /tmp/bayesfl_three_models/install_three_mnist_models.py --repo "$PWD" --check
python /tmp/bayesfl_three_models/install_three_mnist_models.py --repo "$PWD"
```

The installer preserves existing line endings, edits only the model registry and
MNIST model validation, appends the two MLPs, adds a compact CNN file, and creates
one regression test file. It checks file anchors and refuses unexpected source
layouts to avoid silently clobbering local modifications. Backups are saved under
`backups/three_mnist_models/<timestamp>/`.

## Validate before launching any queue

```bash
cd ~/DungNDH/micl/bayesfl
PYTHONPATH="$PWD/src" /home/micl/anaconda3/envs/dungndh/bin/python -m pytest -q \
  tests/test_mnist_model_candidates.py tests/test_models.py tests/test_config.py \
  tests/test_packing.py tests/test_gaussian_product.py tests/test_fola_precision_recurrence.py
```

The added tests cover parameter counts, forward/backward, deterministic
state-vector equality for FedAvg and FOLA, and one local optimizer step for
both methods on an artificial single-class MNIST-sized minibatch.

## Choose a candidate in any existing MNIST YAML template

```yaml
model:
  name: mlp_784_200_200_10
  group_norm_groups: 8
```

Or change only `name` to `mnist_cnn_16_32_128` or `mlp_784_256x3_10`.
The user-facing queue remains a separate step: this patch introduces **no**
new simulation config, resume operation, or queue launch.

Full modified source code is included under `full_modified_files/` for review.
