#!/usr/bin/env python3
"""Install a backwards-compatible opt-in implementation of Paper 00, Algorithm 1.

Usage:
  python install_paper00_strict.py --repo /path/to/bayesfl --check
  python install_paper00_strict.py --repo /path/to/bayesfl --apply

Does not alter FOLA. Legacy behavior remains available when paper00_strict=False.
"""
from __future__ import annotations

import argparse
from pathlib import Path


def adjust(rel: str, src: str) -> str:
    if rel == "src/bayesfl/config.py":
        old = "    grad_clip_norm: Optional[float] = None\n"
        new = old + (
            "    # Opt-in strict replication of Paper 00, Algorithm 1.\n"
            "    # Disabled by default to preserve historical runs and resumes.\n"
            "    paper00_strict: bool = False\n"
        )
        if "    paper00_strict: bool = False\n" not in src:
            assert src.count(old) == 1, f"Could not locate TrainingConfig field in {rel}"
            src = src.replace(old, new, 1)
        validate_old = (
            "        if self.training.grad_clip_norm is not None and self.training.grad_clip_norm <= 0:\n"
            "            raise ValueError(\"grad_clip_norm must be positive when provided\")\n"
        )
        validate_new = validate_old + (
            "        if not isinstance(self.training.paper00_strict, bool):\n"
            "            raise ValueError(\"paper00_strict must be boolean\")\n"
            "        if self.training.paper00_strict:\n"
            "            if self.method != \"fedavg\":\n"
            "                raise ValueError(\"paper00_strict is only for FedAvg\")\n"
            "            if self.training.lr_schedule.lower() not in {\"constant\", \"none\"}:\n"
            "                raise ValueError(\"Paper 00 Algorithm 1 requires a constant learning rate\")\n"
            "            if self.training.momentum != 0.0 or self.training.weight_decay != 0.0:\n"
            "                raise ValueError(\"Paper 00 Algorithm 1 excludes momentum and weight decay\")\n"
            "            if self.training.grad_clip_norm is not None:\n"
            "                raise ValueError(\"Paper 00 Algorithm 1 excludes gradient clipping\")\n"
        )
        if "Paper 00 Algorithm 1 excludes gradient clipping" not in src:
            assert src.count(validate_old) == 1, f"Could not locate validation in {rel}"
            src = src.replace(validate_old, validate_new, 1)
        return src
    if rel == "src/bayesfl/training/deterministic.py":
        old = (
            "    optimizer = torch.optim.SGD(\n"
            "        model.parameters(),\n"
            "        lr=lr,\n"
            "        momentum=cfg.training.momentum,\n"
            "        weight_decay=cfg.training.weight_decay,\n"
            "    )\n"
        )
        new = (
            "    if cfg.training.paper00_strict:\n"
            "        # Paper 00 Algorithm 1: plain mini-batch SGD, nothing extra.\n"
            "        # Config validation rejects momentum, decay, LR schedules and clipping.\n"
            "        cfg.validate()\n"
            "        optimizer = torch.optim.SGD(model.parameters(), lr=lr)\n"
            "    else:\n"
            "        # Unchanged historical project behavior.\n"
            "        optimizer = torch.optim.SGD(\n"
            "            model.parameters(),\n"
            "            lr=lr,\n"
            "            momentum=cfg.training.momentum,\n"
            "            weight_decay=cfg.training.weight_decay,\n"
            "        )\n"
        )
        if "# Paper 00 Algorithm 1: plain mini-batch SGD" not in src:
            assert src.count(old) == 1, f"Could not locate optimizer block in {rel}"
            src = src.replace(old, new, 1)
        old_clip = (
            "            if cfg.training.grad_clip_norm is not None:\n"
            "                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.training.grad_clip_norm)\n"
        )
        new_clip = (
            "            if not cfg.training.paper00_strict and cfg.training.grad_clip_norm is not None:\n"
            "                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.training.grad_clip_norm)\n"
        )
        if new_clip not in src:
            assert src.count(old_clip) == 1, f"Could not locate clipping in {rel}"
            src = src.replace(old_clip, new_clip, 1)
        return src
    if rel == "src/bayesfl/experiment_state.py":
        old = '    data["training"].pop("rounds")\n'
        new = old + (
            "    # Backwards compatible: old checkpoints had no paper00_strict flag.\n"
            "    # Include it only when enabled, so new paper-faithful runs have\n"
            "    # a distinct and immutable resume fingerprint.\n"
            '    if not data["training"].get("paper00_strict", False):\n'
            '        data["training"].pop("paper00_strict", None)\n'
        )
        if "# Backwards compatible: old checkpoints had no paper00_strict flag." not in src:
            assert src.count(old) == 1, f"Could not locate fingerprint in {rel}"
            src = src.replace(old, new, 1)
        return src
    raise AssertionError(rel)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    repo = Path(args.repo).expanduser().resolve()
    files = [
        "src/bayesfl/config.py",
        "src/bayesfl/training/deterministic.py",
        "src/bayesfl/experiment_state.py",
    ]
    planned = []
    for rel in files:
        path = repo / rel
        if not path.is_file():
            raise FileNotFoundError(path)
        raw = path.read_bytes()
        # Preserve the source's original newline convention.
        newline = "\r\n" if b"\r\n" in raw else "\n"
        src = raw.decode("utf-8").replace("\r\n", "\n")
        dst = adjust(rel, src)
        if dst == src:
            print("ALREADY INSTALLED", rel)
        else:
            planned.append((path, raw, dst.replace("\n", newline).encode("utf-8")))
            print("CHECK PASS", rel, "will be updated")
    if args.check:
        print(f"PASS: {len(planned)} source files need changes; no files written")
        return
    for path, before, after in planned:
        backup = path.with_name(path.name + ".before_paper00_strict")
        if not backup.exists():
            backup.write_bytes(before)
        else:
            # Do not overwrite the original backup if running repeatedly.
            assert backup.read_bytes() == before, f"Unexpected source modifications: {path}"
        path.write_bytes(after)
        print("PATCHED", path)
    print("PASS: Paper 00 strict FedAvg profile installed; FOLA source untouched")


if __name__ == "__main__":
    main()
