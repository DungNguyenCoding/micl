# Stage 16 — strict Paper-00 FedAvg and 30-run MNIST reassessment

## Scope

This is an **Algorithm-1-faithful FedAvg implementation**, not a numerical reproduction of Paper 00's original MNIST experiments. It keeps the user's custom MNIST settings: 20 clients, one class/client, 5 or 10 unique samples/client, full participation, 5 local epochs and a shared server initialization each round. Old MLP and compact CNN are the model families chosen by the user, not exactly Paper 00's CNN.

Paper 00 Algorithm 1 performs local mini-batch SGD and sample-count-weighted parameter averaging. The existing repository already has the correct client dispatch, shared initialization, and aggregation. The historical project FedAvg trainer additionally allows momentum, weight decay, gradient-norm clipping, and a learning-rate schedule, which are outside a literal reading of Algorithm 1. The strict profile rejects and bypasses these additions.

## Source modifications

- `src/bayesfl/config.py`: add `training.paper00_strict` (default false) and reject non-standard optimizer settings when it is true.
- `src/bayesfl/training/deterministic.py`: strict mode explicitly uses plain `torch.optim.SGD(model.parameters(), lr=lr)` and never calls gradient clipping. Legacy path unchanged.
- `src/bayesfl/experiment_state.py`: ignore new flag when false for legacy fingerprints, include it when true for strict-run resume protection.

No changes to FOLA, server aggregation, data partitioning, communication math, or model architecture. All modifications are opt-in.

## Installation

Transfer the archive to the BayesFL repository and unzip it there:

```bash
cd ~/DungNDH/micl/bayesfl
unzip -n bayesfl_paper00_stage16_patch_and_queue.zip
python install_paper00_strict.py --repo "$PWD" --check
python install_paper00_strict.py --repo "$PWD" --apply
PYTHONPATH="$PWD/src" /home/micl/anaconda3/envs/dungndh/bin/python -m pytest -q tests/test_paper00_strict.py
```

## Queues

Run preparation (reads existing Stage-11/12/14 YAMLs, creates **new** YAMLs, validates parameter counts and strict configuration flags):

```bash
PYTHONPATH="$PWD/src" /home/micl/anaconda3/envs/dungndh/bin/python scripts/mnist_stage16_paper00.py prepare
PYTHONPATH="$PWD/src" /home/micl/anaconda3/envs/dungndh/bin/python scripts/mnist_stage16_paper00.py partition
```

The queue planner creates two queues of 15 jobs each:

- `scripts/queues/mnist_stage16_paper00_gpu0.txt`
- `scripts/queues/mnist_stage16_paper00_gpu1.txt`

Each GPU receives 5 old-MLP and 10 compact-CNN jobs, providing balanced model workloads. The partition command caches all ten `samples × seed` partitions before launching to avoid concurrent writes.

Run:

```bash
mkdir -p logs
TS=$(date +%Y%m%d_%H%M%S)
nohup bash scripts/_run_gpu_queue.sh 0 scripts/queues/mnist_stage16_paper00_gpu0.txt > logs/stage16_paper00_gpu0_${TS}.log 2>&1 &
nohup bash scripts/_run_gpu_queue.sh 1 scripts/queues/mnist_stage16_paper00_gpu1.txt > logs/stage16_paper00_gpu1_${TS}.log 2>&1 &
```

After **both** queue logs say `GPU QUEUE FINISHED`:

```bash
PYTHONPATH="$PWD/src" /home/micl/anaconda3/envs/dungndh/bin/python scripts/mnist_stage16_paper00.py results
```

This prints per-seed checkpoints, five-seed means/SD, late-round stability, and optional comparisons against previously run clipped FedAvg and FOLA.

## Locked experimental settings

| Model | LR | B | E | N | samples/client | seeds | rounds |
|---|---:|---:|---:|---:|---:|---|---:|
| Old MLP `784→500→300→10` | 0.01 | 128 | 5 | 20 | 5, 10 | 0–4 | 400 |
| Compact CNN `Conv16→Conv32→FC128` | 0.03 | 5 or 10 | 5 | 20 | 5, 10 | 0–4 | 400 |
| Compact CNN `Conv16→Conv32→FC128` | 0.10 | 5 or 10 | 5 | 20 | 5, 10 | 0–4 | 400 |

- Each client has exactly one digit class; each digit is represented by exactly two clients.
- All 20 clients participate in every round.
- For old MLP, B=128 acts as full-local-batch SGD because each client has only 5 or 10 samples.
- SGD uses constant LR, no momentum, weight decay or clipping.
- Communication accounting uses multicast downlink + 20 dense model uplinks.
- Results must be interpreted against earlier **clipped** baselines with the changed clipping policy explicitly labeled. Comparing new unclipped FedAvg to previously clipped FOLA mixes clipping policies and must be disclosed.

## Idempotency/compatibility

The installer first checks expected source regions and backs up originals to `*.before_paper00_strict` before writing. Applying it again reports `ALREADY INSTALLED`. A new fingerprint field is excluded when strict mode is false, protecting compatibility with existing checkpoints. The generator fails rather than overwriting conflicting YAMLs or previously started outputs.
