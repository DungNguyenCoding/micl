# MNIST Stage-22 s10 — independent two-GPU multiseed queues (v2)

This **replaces only** `scripts/mnist_stage22_s10_multiseed.py` from the earlier v1 package. It changes **orchestration only**. Neither the scientific experiment configurations nor FOLA/FedKLS/FedAvg algorithms are modified.

## Scheduling semantics

- **GPU 0:** seed1: dense FOLA R150, KL r=.75 R193, KL r=.25 R498, KL r=.05 R1362; then **immediately** seed2 with the same four methods, ... seed9.
- **GPU 1:** seed1: clipped FedAvg R300, random r=.75 R193, random r=.25 R498, random r=.05 R1362; then **immediately** seed2 with the same four methods, ... seed9.
- Jobs on *each individual GPU* are **sequential** (no overlapping workers on the same GPU). The GPU queues run **in parallel and independently**: no cross-GPU barrier between seeds.
- As soon as **both GPUs finish all their jobs** for seed s, the controller checks those results and writes a `summary_through_seed{s}` snapshot **without holding either GPU back**. When you run `summary --through 5`, only the contiguous set of completely paired seeds from 0 onward is aggregated; partial seeds are excluded.
- On any job failure, future jobs on both GPU queues are stopped as soon as their **currently running jobs** finish; results are never overwritten or silently resumed. The existing global lock prevents multiple controllers from running concurrently.

The study name, manifest, 72 configurations, partition caches, run names, seed-0 reuse, budget 2,021,090,400 bytes, and `prepare`, `run`, `status`, `summary` CLI remain unchanged from v1. If the v1 `prepare` command already succeeded, **do not regenerate anything**; just replace the Python file.

## Replace v1 file (do not hot-replace an active controller)

Copy `FedKLS_MNIST_s10_multiseed_two_gpu_v2.zip` to `/tmp/` on the SSH host. Then:

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"

# Check for a running old controller or training job FIRST.
pgrep -af 'mnist_stage22_s10_multiseed.py run|bayesfl.main' || true
# Do not overwrite the script while a v1 controller is running.

cp scripts/mnist_stage22_s10_multiseed.py scripts/mnist_stage22_s10_multiseed.v1.backup.py
unzip -p /tmp/FedKLS_MNIST_s10_multiseed_two_gpu_v2.zip \
  scripts/mnist_stage22_s10_multiseed.py > /tmp/fedkls_multiseed_v2.py
"$PY" -B -m py_compile /tmp/fedkls_multiseed_v2.py
cp /tmp/fedkls_multiseed_v2.py scripts/mnist_stage22_s10_multiseed.py
"$PY" -B scripts/mnist_stage22_s10_multiseed.py run --help
```

An older `nohup` process that already imported v1 does **not** switch to v2 automatically. Let it finish or stop it deliberately after checking its jobs, then launch the new controller. Never launch a second controller on the same study concurrently.

## Launch seeds 1–9 (manual nohup)

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
mkdir -p logs/mnist_stage22_s10_multiseed_v1
STAMP=$(date +%Y%m%d_%H%M%S)
BASE="logs/mnist_stage22_s10_multiseed_v1/seed1to9_independent_${STAMP}"
nohup bash -c '
  "$1" -B scripts/mnist_stage22_s10_multiseed.py run \
    --start-seed 1 --end-seed 9
  rc=$?
  printf "%s\n" "$rc" > "$2"
  exit "$rc"
' _ "$PY" "${BASE}.exit" > "${BASE}.controller.log" 2>&1 < /dev/null &
echo $! | tee "${BASE}.pid"
echo "LOG=${BASE}.controller.log"
echo "EXIT=${BASE}.exit"
```

If seed 1 has **not** yet been tested on your host, prefer running `--start-seed 1 --end-seed 1` first. Once complete and verified, run `--start-seed 2 --end-seed 9` in a new command. Do not restart partial/failed jobs without checking their output state.

## Monitor

```bash
cd ~/DungNDH/micl/bayesfl
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" -B scripts/mnist_stage22_s10_multiseed.py status | grep '^SEED '
LATEST=$(ls -t logs/mnist_stage22_s10_multiseed_v1/*independent_*.controller.log | head -1)
tail -n 40 "$LATEST"
BASE="${LATEST%.controller.log}"
if test -f "${BASE}.exit"; then cat "${BASE}.exit"; else echo "Still running, or aborted before recording exit"; fi
nvidia-smi
```

Typical controller lines (not synchronized):

```text
GPU 0 SEED 1 LANE COMPLETE -> NEXT SEED WITHOUT WAITING FOR GPU PEER
GPU 0 SEED 2 START
GPU 1 SEED 1 LANE COMPLETE -> NEXT SEED WITHOUT WAITING FOR GPU PEER
SEED 1 BOTH LANES COMPLETE — REPORTING (NO BARRIER)
```

## Incremental summary during training

```bash
cd ~/DungNDH/micl/bayesfl
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" -B scripts/mnist_stage22_s10_multiseed.py summary --through 5
```

Outputs under `reports/mnist_stage22_s10_multiseed_v1/` include `summary_through_seed5.md`, `.csv`, `_per_seed.csv`, and `.json`. If GPU 0 has completed seed 7 but GPU 1 is still on seed 5, the summary **does not include seed 5 until both GPU lanes complete it**, and seed 6–7 remain excluded too. Once all seeds are done:

```bash
"$PY" -B scripts/mnist_stage22_s10_multiseed.py summary --through 9
```

## Verification

In a dry-run test (with training and result loading mocked, **no CUDA/Ray training**), GPU 0 advanced into seed 2 before GPU 1 finished seed 1; individual GPU jobs remained serial; and each seed report appeared only after both lanes finished. Python compilation also passed. Actual training must still be verified on your host.
