#!/usr/bin/env python3
"""Two-GPU, seed-barrier MNIST s10/20-client Stage-22 experiment.

The original learning code is not modified. Each seed runs FOLA dense and
three KL selections on GPU0 and clipped FedAvg and their random selectors on
GPU1. The next seed begins only after both GPU lanes finish and validate.

Commands: prepare | run | status | summary.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import copy
import csv
import fcntl
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys
import tempfile
import threading
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
STUDY = "mnist_stage22_s10_multiseed_v1"
STUDY_DIR = ROOT / "scripts" / "configs" / STUDY
REPORT_DIR = ROOT / "reports" / STUDY
LOG_DIR = ROOT / "logs" / STUDY
OUTPUT_DIR = ROOT / "outputs"
MANIFEST = STUDY_DIR / "study_manifest.json"
BUDGET = 2_021_090_400
D = 80_202
K = 20
FIRST_SEED = 1
LAST_SEED = 9
SEL_RATIOS = (0.75, 0.25, 0.05)
ALL_RATIOS = (0.75, 0.50, 0.25, 0.10, 0.05)
DENSE_FOLA_TEMPLATE = (
    "scripts/configs/mnist_stage18_fola_noclip_cnn/"
    "run_mnist_stage18_cnn16_32_fola_noclip_fixed1c_s10_n20_"
    "seed0_e5_b10_lr0p10_lam0p01_r200.yaml"
)
FEDAVG_TEMPLATE = (
    "scripts/configs/mnist_stage23_recovery/"
    "run_mnist_stage23_cnn16_32_fixed1c_s10_n20_"
    "fedavg_clip_seed0_e5_b10_lr0p10_r400.yaml"
)
OLD_FOLA = (
    "run_mnist_stage18_cnn16_32_fola_noclip_fixed1c_s10_n20_"
    "seed0_e5_b10_lr0p10_lam0p01_r200"
)
OLD_FEDAVG = (
    "run_mnist_stage23_cnn16_32_fixed1c_s10_n20_fedavg_clip_"
    "seed0_e5_b10_lr0p10_r400"
)
OLD_SPARSE = "run_mnist_stage22_cnn_s10_n20_seed0_fola_{rule}_keep{tag}_budget150_r{rounds}"


def log(*args):
    print(datetime.now().astimezone().isoformat(timespec="seconds"), "|", *args, flush=True)


def ratio_tag(r: float) -> str:
    return f"{r:.2f}".replace(".", "p")


def short_key(rule: str, ratio: float) -> str:
    return f"{rule}_keep{ratio_tag(ratio)}"


def specs(ratios: tuple[float, ...]) -> list[dict]:
    # Scientific load balance: selected3 GPU0 2203 rounds vs GPU1 2353.
    jobs = [
        dict(key="fola_dense", gpu=0, method="fola", rule="dense", ratio=1.0, rounds=150),
        dict(key="fedavg_dense", gpu=1, method="fedavg", rule="dense", ratio=1.0, rounds=300),
    ]
    for ratio in ratios:
        jobs.append(dict(key=short_key("kl_global_local", ratio), gpu=0,
                         method="fola", rule="kl_global_local", ratio=ratio))
        jobs.append(dict(key=short_key("random", ratio), gpu=1,
                         method="fola", rule="random", ratio=ratio))
    return jobs


def byte_cost(job: dict) -> int:
    from bayesfl.communication import core_round_bytes
    from bayesfl.posterior.sparse import keep_count
    if job["rule"] == "dense":
        kw = dict(method=job["method"], downlink_mode="multicast")
    else:
        kw = dict(method="fola", downlink_mode="multicast", sparse=True,
                  m=keep_count(D, job["ratio"]))
    return int(core_round_bytes(D, K, **kw)["total_bytes"])


def old_name(job: dict) -> str:
    if job["key"] == "fola_dense":
        return OLD_FOLA
    if job["key"] == "fedavg_dense":
        return OLD_FEDAVG
    return OLD_SPARSE.format(rule=job["rule"], tag=ratio_tag(job["ratio"]),
                             rounds=job["rounds"])


def new_name(seed: int, job: dict) -> str:
    return f"run_{STUDY}_seed{seed}_{job['key']}_r{job['rounds']}"


def verified_template(path: Path, method: str):
    from bayesfl.config import load_config
    cfg = load_config(path)
    assert cfg.runtime.seed == 0 and cfg.method == method
    assert cfg.model.name == "mnist_cnn_16_32_128"
    assert cfg.data.dataset == "mnist" and not cfg.data.augment
    assert cfg.data.partition == {"type": "fixed_labels", "samples_per_client": 10,
                                  "labels_per_client": 1}
    assert (cfg.federation.num_clients, cfg.federation.clients_per_round) == (20, 20)
    t = cfg.training
    assert (t.optimizer, t.lr, t.momentum, t.weight_decay) == ("sgd", .1, 0., 0.)
    assert (t.local_epochs, t.batch_size, t.lr_schedule) == (5, 10, "constant")
    assert t.grad_clip_norm == (None if method == "fola" else 10.0)
    assert cfg.fola.mode == "paper_reference" and cfg.fola.prior_lambda == .01
    assert cfg.communication.downlink_mode == "multicast"
    return cfg


def generate_config(template, seed, job: dict) -> dict:
    raw = copy.deepcopy(template.to_dict())
    raw["run_name"] = new_name(seed, job)
    raw["runtime"]["seed"] = seed
    raw["training"]["rounds"] = job["rounds"]
    raw["compression"].update(
        selection_rule=job["rule"], keep_ratio=job["ratio"],
        covariance_representation="precision", precision_policy="strict",
        score_precision_floor=None,
    )
    raw["communication"].update(
        max_communication_bytes=BUDGET,
        budget_metric="cumulative_all_array_bytes", downlink_mode="multicast",
        deterministic_client_schedule=True,
    )
    raw["output"]["save_full_client_posteriors"] = False
    return raw


def atomic_text(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def read_manifest():
    if not MANIFEST.exists():
        raise RuntimeError(f"Missing {MANIFEST}; run 'prepare' first")
    m = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if m.get("study") != STUDY or m.get("budget_bytes") != BUDGET:
        raise RuntimeError("Incompatible manifest")
    if m.get("seeds") != list(range(FIRST_SEED, LAST_SEED + 1)):
        raise RuntimeError("Unexpected seeded manifest")
    return m


def prepare(args):
    import torch
    import yaml
    from bayesfl.config import load_config
    from bayesfl.models.factory import initialize_model
    from bayesfl.data.datasets import partition_stem, prepare_partition
    from bayesfl.data.partition import load_partition, _hash_partitions

    ratios = ALL_RATIOS if args.all_ratios else SEL_RATIOS
    jobs = specs(ratios)
    for job in jobs:
        job["round_bytes"] = byte_cost(job)
        if job["rule"] != "dense":
            job["rounds"] = BUDGET // job["round_bytes"]
        assert job["rounds"] * job["round_bytes"] <= BUDGET
        assert (job["rounds"] + 1) * job["round_bytes"] > BUDGET
    assert jobs[0]["round_bytes"] * 150 == BUDGET
    assert jobs[1]["round_bytes"] * 300 == BUDGET
    rounds_by_gpu = {str(g): sum(j["rounds"] for j in jobs if j["gpu"] == g)
                     for g in (0, 1)}
    assert all(sum(j["gpu"] == g for j in jobs) == len(jobs) // 2 for g in (0, 1))
    fola = verified_template(ROOT / DENSE_FOLA_TEMPLATE, "fola")
    fedavg = verified_template(ROOT / FEDAVG_TEMPLATE, "fedavg")
    assert sum(p.numel() for p in initialize_model(fola).parameters()) == D
    assert sum(p.numel() for p in initialize_model(fedavg).parameters()) == D

    payload = dict(study=STUDY, budget_bytes=BUDGET, seed0_reused=True,
                   seeds=list(range(FIRST_SEED, LAST_SEED + 1)),
                   ratios=list(ratios), jobs=jobs, gpu_rounds_per_seed=rounds_by_gpu,
                   templates=dict(fola=DENSE_FOLA_TEMPLATE, fedavg=FEDAVG_TEMPLATE))
    if MANIFEST.exists():
        old = read_manifest()
        if old != payload:
            raise RuntimeError(f"Manifest conflict: {MANIFEST}; do not overwrite an existing study")

    # Validate all resulting configs before creating any new YAMLs.
    generated = {}
    stems = {}
    paired_dense_configs = {}
    for seed in payload["seeds"]:
        for job in jobs:
            raw = generate_config(fola if job["method"] == "fola" else fedavg, seed, job)
            path = STUDY_DIR / f"{raw['run_name']}.yaml"
            if path.exists() and yaml.safe_load(path.read_text(encoding="utf-8")) != raw:
                raise RuntimeError(f"Existing YAML differs, not overwriting: {path}")
            # Load through the exact repository loader even before writing YAML.
            if path.exists():
                valid = load_config(path)
            else:
                with tempfile.TemporaryDirectory(prefix="fedkls_config_check_") as tempdir:
                    temp_path = Path(tempdir) / f"{raw['run_name']}.yaml"
                    temp_path.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")
                    valid = load_config(temp_path)
            assert valid.to_dict() == raw
            assert valid.runtime.seed == seed and valid.training.rounds == job["rounds"]
            assert valid.compression.selection_rule == job["rule"]
            assert valid.communication.max_communication_bytes == BUDGET
            stem = partition_stem(valid)
            assert seed not in stems or stems[seed] == stem
            stems[seed] = stem
            if job["key"] in ("fola_dense", "fedavg_dense"):
                paired_dense_configs[(seed, job["key"])] = valid
            generated[path] = raw

    # Match initialization across FOLA, FedKLS and FedAvg per seed.
    for seed in payload["seeds"]:
        f_model = initialize_model(paired_dense_configs[(seed, "fola_dense")])
        a_model = initialize_model(paired_dense_configs[(seed, "fedavg_dense")])
        f_state = f_model.state_dict()
        a_state = a_model.state_dict()
        if f_state.keys() != a_state.keys() or not all(
            torch.equal(f_state[name], a_state[name]) for name in f_state
        ):
            raise RuntimeError(f"Dense FOLA/FedAvg seed{seed} model initialization differs")

    STUDY_DIR.mkdir(parents=True, exist_ok=True)
    for path, raw in generated.items():
        if not path.exists():
            atomic_text(path, yaml.safe_dump(raw, sort_keys=False))
    if not MANIFEST.exists():
        atomic_text(MANIFEST, json.dumps(payload, indent=2) + "\n")

    # Seed 0 is the historical reference (no training or overwriting it).
    for job in jobs:
        old_result, old_issue = extract_completed(0, job, existing_seed0=True)
        if old_result is None:
            raise RuntimeError(f"Seed-0 reference missing/incomplete for {job['key']}: {old_issue}")
    log("SEED 0 VERIFIED", len(jobs), "historical jobs at their comparison endpoints")

    if not args.skip_partitions:
        for seed in payload["seeds"]:
            cfg = load_config(STUDY_DIR / f"{new_name(seed, jobs[0])}.yaml")
            part_file, meta = prepare_partition(cfg)
            indices = load_partition(part_file)
            assert len(indices) == K and all(len(ids) == 10 for ids in indices)
            assert len(set(int(i) for ids in indices for i in ids)) == 200
            assert _hash_partitions(indices) == meta["sha256"]
            log("PARTITION", seed, part_file, meta["sha256"][:16])
    else:
        log("NOTE: partitions not prepared; runner will refuse until prepared")
    log("PREPARED", len(generated), "configs |", len(jobs), "jobs/seed",
        "| GPU rounds/seed", rounds_by_gpu, "| budget", BUDGET)
    log("MANIFEST", MANIFEST)


def run_candidates(name: str) -> list[Path]:
    # Exact-name directories are supported alongside timestamped run IDs.
    paths = [OUTPUT_DIR / name]
    paths.extend(OUTPUT_DIR.glob(name + "_*"))
    return sorted({p.resolve() for p in paths if p.is_dir()})


def extract_completed(seed: int, job: dict, *, existing_seed0: bool = False):
    """Return (accuracy%, run_path), or (None, reason). Never trust partial CSVs."""
    name = old_name(job) if existing_seed0 else new_name(seed, job)
    candidates = run_candidates(name)
    if not candidates:
        return None, "NOT_STARTED"
    if len(candidates) != 1:
        return None, "MULTIPLE_RUNS:" + ",".join(str(p) for p in candidates)
    path = candidates[0]
    metrics = path / "metrics" / "global_metrics.csv"
    summary_path = path / "run_summary.json"
    if not metrics.exists() or not summary_path.exists():
        return None, f"INCOMPLETE:{path}"
    try:
        info = json.loads(summary_path.read_text(encoding="utf-8"))
        expected_round = int(job["rounds"])
        complete_round = int(info["round_id"])
        if complete_round < expected_round or info.get("stop_reason") not in (
            "max_rounds", "communication_budget") or info.get("failure"):
            raise ValueError(f"round={complete_round}, stop={info.get('stop_reason')}")
        with metrics.open(newline="", encoding="utf-8") as f:
            rows = {int(float(r["round"])): r for r in csv.DictReader(f) if r.get("round")}
        if not all(r in rows for r in range(0, expected_round + 1)):
            raise ValueError("Missing evaluated round(s)")
        final = rows[expected_round]
        if int(float(final["cumulative_all_array_bytes"])) != job["round_bytes"] * expected_round:
            raise ValueError("Modeled array-byte mismatch")
        if int(float(final["seed"])) != seed:
            raise ValueError("Seed mismatch")
        if final.get("selection_rule") != job["rule"]:
            raise ValueError("Selector mismatch")
        if final.get("downlink_mode") != "multicast" or int(float(final["d"])) != D:
            raise ValueError("Communication/model identity mismatch")
        if not existing_seed0:
            from bayesfl.config import load_config
            actual_cfg = load_config(path / "resolved_config.yaml")
            requested_cfg = load_config(STUDY_DIR / f"{name}.yaml")
            if actual_cfg.to_dict() != requested_cfg.to_dict():
                raise ValueError("Resolved config differs from planned run")
        key = "fola_mean_accuracy" if job["method"] == "fola" else "accuracy"
        value = float(final[key])
        if not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError(f"Invalid accuracy: {value}")
        return (100 * value, path), None
    except Exception as ex:
        return None, f"INVALID:{path}:{ex}"


def job_status(seed: int, job: dict):
    value, reason = extract_completed(seed, job)
    return "COMPLETE" if value is not None else reason


def run_job(seed: int, job: dict, stop: threading.Event):
    config = STUDY_DIR / f"{new_name(seed, job)}.yaml"
    result, reason = extract_completed(seed, job)
    if result is not None:
        log("SKIP VERIFIED", seed, job["key"], "GPU", job["gpu"])
        return
    if reason != "NOT_STARTED":
        raise RuntimeError(f"Refusing to overwrite/restart {job['key']} seed{seed}: {reason}")
    if stop.is_set():
        return
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOG_DIR / f"{new_name(seed, job)}.log"
    if log_path.exists():
        raise RuntimeError(f"Log exists without verified run; inspect before retry: {log_path}")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(job["gpu"])
    env["PATH"] = str(Path(sys.executable).parent) + os.pathsep + env.get("PATH", "")
    env["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + env.get("PYTHONPATH", "")
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    cmd = [sys.executable, "-B", "-m", "bayesfl.main", "--config", str(config)]
    log("START", "seed", seed, "GPU", job["gpu"], job["key"], "rounds", job["rounds"])
    with log_path.open("x", encoding="utf-8") as f:
        f.write("COMMAND " + " ".join(cmd) + "\n")
        f.write(f"GPU={job['gpu']} SEED={seed} START={datetime.now(timezone.utc).isoformat()}\n")
        f.flush()
        rc = subprocess.run(cmd, cwd=ROOT, env=env, stdout=f,
                            stderr=subprocess.STDOUT, check=False).returncode
        f.write(f"\nEXIT_CODE={rc} END={datetime.now(timezone.utc).isoformat()}\n")
    if rc:
        stop.set()
        raise RuntimeError(f"Training failed GPU{job['gpu']} seed{seed} {job['key']} exit={rc}; {log_path}")
    result, reason = extract_completed(seed, job)
    if result is None:
        stop.set()
        raise RuntimeError(f"Job exited 0 but result invalid: GPU{job['gpu']} seed{seed} {job['key']}: {reason}")
    log("PASS", "seed", seed, "GPU", job["gpu"], job["key"], f"acc={result[0]:.2f}%")


def run_lane(seed: int, gpu: int, jobs: list[dict], stop: threading.Event):
    for job in jobs:
        if stop.is_set():
            return
        run_job(seed, job, stop)


def run(args):
    m = read_manifest()
    if not 1 <= args.start_seed <= args.end_seed <= LAST_SEED:
        raise ValueError("Seed range must satisfy 1 <= start <= end <= 9")
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = LOG_DIR / "controller.lock"
    with lock_path.open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as ex:
            raise RuntimeError("Another multiseed controller already owns the lock") from ex
        # Refuse Ray startup when the sequentially cached partitions are missing.
        from bayesfl.config import load_config
        from bayesfl.data.datasets import partition_stem
        for seed in range(args.start_seed, args.end_seed + 1):
            cfg = load_config(STUDY_DIR / (new_name(seed, m["jobs"][0]) + ".yaml"))
            stem = partition_stem(cfg)
            if not (OUTPUT_DIR / "partitions" / f"{stem}.npz").is_file() or not (
                OUTPUT_DIR / "partitions" / f"{stem}.json").is_file():
                raise RuntimeError(f"Missing partition cache for seed{seed}: {stem}; run prepare")
        # Require all historical seed-0 comparison endpoints before spending GPU time.
        for job in m["jobs"]:
            old_value, old_issue = extract_completed(0, job, existing_seed0=True)
            if old_value is None:
                raise RuntimeError(f"Historical seed-0 result is missing: {job['key']}: {old_issue}")
        # Each seed has a full two-GPU barrier: neither lane may advance before both pass.
        for seed in range(args.start_seed, args.end_seed + 1):
            log("========== SEED", seed, "START ==========")
            stop = threading.Event()
            failure = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                futures = {pool.submit(run_lane, seed, gpu,
                         [j for j in m["jobs"] if j["gpu"] == gpu], stop): gpu
                         for gpu in (0, 1)}
                for f in concurrent.futures.as_completed(futures):
                    try:
                        f.result()
                    except Exception as ex:
                        stop.set()
                        failure.append((futures[f], str(ex)))
            if failure:
                for gpu, msg in failure:
                    log("FAILED", "seed", seed, "GPU", gpu, msg)
                raise RuntimeError(f"Seed {seed} incomplete; no later seed will be launched")
            # Avoid claiming complete if either lane silently skipped tasks.
            for job in m["jobs"]:
                result, reason = extract_completed(seed, job)
                if result is None:
                    raise RuntimeError(f"Seed{seed} incomplete after workers: {job['key']}: {reason}")
            log("========== SEED", seed, "BOTH GPU LANES COMPLETE ==========")
            # This is only a read of completed metrics; it can be done during later runs too.
            make_summary(seed, write=True, quiet=True)
        log("ALL REQUESTED SEEDS VERIFIED COMPLETE")


def statuses(args):
    m = read_manifest()
    for seed in (0, *m["seeds"]):
        records = []
        for job in m["jobs"]:
            value, reason = extract_completed(seed, job, existing_seed0=(seed == 0))
            records.append((job["key"], f"{value[0]:.2f}%" if value else reason))
        passed = sum("%" in s for _, s in records)
        print(f"SEED {seed}: {passed}/{len(records)} complete")
        for key, status in records:
            print(f"  {key:32} {status}")


def make_summary(through: int, *, write: bool, quiet: bool = False):
    m = read_manifest()
    if not 0 <= through <= LAST_SEED:
        raise ValueError("--through must be in 0..9")
    requested = list(range(0, through + 1))
    complete_seeds = []
    rows = []
    waiting = {}
    for seed in requested:
        observed = {}
        failures = []
        for job in m["jobs"]:
            result, reason = extract_completed(seed, job, existing_seed0=(seed == 0))
            if result is None:
                failures.append(f"{job['key']} ({reason})")
            else:
                observed[job['key']] = dict(acc_pct=result[0], run_dir=str(result[1]),
                                            array_bytes=job['rounds']*job['round_bytes'])
        if failures:
            waiting[str(seed)] = failures
            continue
        complete_seeds.append(seed)
        for job in m["jobs"]:
            rows.append(dict(seed=seed, method=job["key"], gpu=job["gpu"],
                             rounds=job["rounds"], **observed[job['key']]))
    # Only contiguous completed seed pairs from 0 are comparable as a growing sample.
    prefix = []
    for s in requested:
        if s in complete_seeds:
            prefix.append(s)
        else:
            break
    paired = [r for r in rows if r["seed"] in prefix]
    grouped = []
    for job in m["jobs"]:
        vals = [r["acc_pct"] for r in paired if r["method"] == job["key"]]
        if not vals:
            continue
        grouped.append(dict(method=job["key"], n=len(vals), mean_pct=statistics.mean(vals),
                            sd_pp=statistics.stdev(vals) if len(vals)>1 else None,
                            min_pct=min(vals), max_pct=max(vals), rounds=job["rounds"],
                            budget_bytes=BUDGET))
    payload = dict(study=STUDY, requested_through_seed=through,
                   contiguous_complete_seeds=prefix, other_complete_seeds=sorted(set(complete_seeds)-set(prefix)),
                   pending_or_invalid=waiting, per_seed=paired, summary=grouped,
                   note="Seed count is over complete pairs only. Modeled array-byte budget; not physical wireless time.")
    if not quiet:
        print("Completed contiguous paired seeds:", prefix or "none")
        print("Pending seeds:", ",".join(waiting) if waiting else "none")
        print("Method                              N  Mean Acc %   SD pp    Min–Max %")
        for x in grouped:
            sd = f"{x['sd_pp']:.3f}" if x["sd_pp"] is not None else "N/A"
            print(f"{x['method']:35} {x['n']:2} {x['mean_pct']:10.3f} {sd:>7} "
                  f"{x['min_pct']:6.2f}–{x['max_pct']:6.2f}")
    if write:
        REPORT_DIR.mkdir(parents=True, exist_ok=True)
        stem = f"summary_through_seed{through}"
        atomic_text(REPORT_DIR / f"{stem}.json", json.dumps(payload, indent=2) + "\n")
        lines = ["method,n,mean_accuracy_pct,sd_pp,min_pct,max_pct,rounds,budget_bytes"]
        for x in grouped:
            lines.append(f"{x['method']},{x['n']},{x['mean_pct']:.8f},"
                         f"{'' if x['sd_pp'] is None else format(x['sd_pp'], '.8f')},"
                         f"{x['min_pct']:.8f},{x['max_pct']:.8f},{x['rounds']},{BUDGET}")
        atomic_text(REPORT_DIR / f"{stem}.csv", "\n".join(lines) + "\n")
        per_seed_path = REPORT_DIR / f"{stem}_per_seed.csv"
        with_lines = ["seed,method,accuracy_pct,rounds,model_array_bytes,run_dir"]
        for record in paired:
            # CSV quoting is handled for paths should they contain commas.
            import io
            buffer = io.StringIO()
            writer = csv.writer(buffer)
            writer.writerow([record["seed"], record["method"],
                             f"{record['acc_pct']:.8f}", record["rounds"],
                             record["array_bytes"], record["run_dir"]])
            with_lines.append(buffer.getvalue().rstrip("\r\n"))
        atomic_text(per_seed_path, "\n".join(with_lines) + "\n")
        md = [f"# MNIST Stage-22 s10 multiseed through seed {through}", "",
              f"**Complete paired seeds:** {prefix or 'none'}", "",
              "Only complete seed-level method sets are included; incomplete runs are excluded.", "",
              "| Method | N | Accuracy mean (%) | SD (pp) | Range (%) | Rounds |",
              "|---|---:|---:|---:|---:|---:|"]
        for x in grouped:
            md.append(f"| {x['method']} | {x['n']} | {x['mean_pct']:.3f} | "
                      f"{('—' if x['sd_pp'] is None else format(x['sd_pp'], '.3f'))} | "
                      f"{x['min_pct']:.2f}–{x['max_pct']:.2f} | {x['rounds']} |")
        if waiting:
            md.extend(["", "## Missing/incomplete seeds", ""])
            md.extend(f"- Seed {s}: {'; '.join(v)}" for s,v in waiting.items())
        md.extend(["", "Budget: 2,021,090,400 modeled model-array bytes; shared multicast; "
                   "no wireless fading/channel simulation.", "",
                   "Seed 0 uses the existing Stage-18 dense R200, Stage-23 clipped FedAvg R400 "
                   "(both evaluated at R150/R300), and Stage-22 sparse runs.", ""])
        atomic_text(REPORT_DIR / f"{stem}.md", "\n".join(md))
        if not quiet:
            print("WROTE", REPORT_DIR / f"{stem}.md")
    return payload


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="action", required=True)
    a = sub.add_parser("prepare", help="Generate seed1-9 configs and precompute partitions")
    a.add_argument("--all-ratios", action="store_true", help="Use all five Stage-22 ratios instead of selected three")
    a.add_argument("--skip-partitions", action="store_true", help="For offline config validation only")
    b = sub.add_parser("run", help="Run both GPU lanes per seed, with a barrier before next seed")
    b.add_argument("--start-seed", type=int, default=1)
    b.add_argument("--end-seed", type=int, default=9)
    sub.add_parser("status", help="Read-only per-seed job completion status")
    c = sub.add_parser("summary", help="Summarize fully completed seed pairs while later seeds run")
    c.add_argument("--through", type=int, default=9)
    c.add_argument("--no-write", action="store_true")
    args = p.parse_args()
    os.chdir(ROOT)
    if args.action == "prepare":
        prepare(args)
    elif args.action == "run":
        run(args)
    elif args.action == "status":
        statuses(args)
    else:
        make_summary(args.through, write=not args.no_write)


if __name__ == "__main__":
    main()
