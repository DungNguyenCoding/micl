# MNIST Stage-22 s10 multiseed, two GPU lanes, seeds 1–9

Only one new file is installed under your original `~/DungNDH/micl/bayesfl`:

`scripts/mnist_stage22_s10_multiseed.py`.

No FOLA, KL, packet, allocation, or learning code was changed.

## Experiment definition

Matches the MNIST s10/seed0 Stage-22 `Acc_Com` setup. A full two-GPU barrier is enforced between seeds: seed `s+1` starts only after **both** GPU lanes have completed all jobs for seed `s` with valid run summaries and exact byte-budget accounting.

- 20 clients, 10 fixed-label MNIST samples per client, one label/client, full participation.
- `mnist_cnn_16_32_128`, 80,202 trainable parameters.
- E=5, B=10, SGD lr=0.1, momentum=0, weight decay=0, constant LR.
- FOLA `paper_reference`, lambda=0.01, FOLA no gradient clipping.
- Historical Stage-23 FedAvg gradient clipping norm=10 (matching the selected plot).
- Full FOLA R150; FedAvg R300; sparse KL and random controls:
  r=0.75/R193, r=0.25/R498, r=0.05/R1362.
- All use modeled array-byte budget 2,021,090,400 and multicast accounting.
- Seed 0 is read **from existing historical outputs** (Stage-18 FOLA R200 sliced at R150, Stage-23 FedAvg R400 sliced at R300, and Stage-22 sparse runs). It is **not retrained or modified**.
- By default there are **8 jobs per new seed**, 4 jobs per GPU, 72 jobs total for seeds 1–9. Random controls are included to support KL-versus-random analysis; the Acc–Communication figure itself may display only KL.
- Option `prepare --all-ratios` replaces the selected three with five Stage-22 ratios. Choose this before the first prepare and do not mix modes in one study folder.

| GPU0 (serial within seed) | Rounds | GPU1 (serial within seed) | Rounds |
|---|---:|---|---:|
| FOLA dense | 150 | FedAvg clipped | 300 |
| FedKLS KL r=0.75 | 193 | Random r=0.75 | 193 |
| FedKLS KL r=0.25 | 498 | Random r=0.25 | 498 |
| FedKLS KL r=0.05 | 1362 | Random r=0.05 | 1362 |
| **Total GPU0** | **2203** | **Total GPU1** | **2353** |

The round count is a workload guide, not an actual runtime estimate. Each GPU works on the *same seed* concurrently and is blocked at the end of that seed until both lanes finish. Failure prevents the next seed from starting.

## Install on SSH server

From your machine, copy the downloaded Python script to `~/DungNDH/micl/bayesfl/scripts/mnist_stage22_s10_multiseed.py`. If using the ZIP, extract it at the repository root (inspect the ZIP file names first). Then:

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" --version
```

### 1) Prepare all nine partitions and configs (no training)

```bash
"$PY" -B scripts/mnist_stage22_s10_multiseed.py prepare
```

Preparation validates all 72 configs through the **existing** `load_config`, checks paired model initialization and the exact budget, verifies seed-0 outputs, and caches the nine seeded partitions *sequentially* before multi-GPU launches.

### 2) Launch manually with nohup (one controller for both GPUs)

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
mkdir -p logs/mnist_stage22_s10_multiseed_v1
STAMP=$(date +%Y%m%d_%H%M%S)
BASE="logs/mnist_stage22_s10_multiseed_v1/seed1to9_${STAMP}"
nohup bash -c '
  "$1" -B scripts/mnist_stage22_s10_multiseed.py run --start-seed 1 --end-seed 9
  rc=$?
  printf "%s\n" "$rc" > "$2"
  exit "$rc"
' _ "$PY" "${BASE}.exit" > "${BASE}.controller.log" 2>&1 < /dev/null &
echo $! | tee "${BASE}.pid"
echo "Controller log: ${BASE}.controller.log"
echo "Final exit file: ${BASE}.exit"
```

The `nohup` process remains on the persistent SSH host independently of VS Code or chat sessions, but not through a host reboot. If you want a smaller first test, change `--end-seed 9` to `--end-seed 1`, then use a second separate launch `--start-seed 2 --end-seed 9` after verifying seed 1.

### 3) Monitor read-only (in a new terminal)

```bash
cd ~/DungNDH/micl/bayesfl
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" -B scripts/mnist_stage22_s10_multiseed.py status | grep '^SEED '
LATEST=$(ls -t logs/mnist_stage22_s10_multiseed_v1/seed1to9_*.controller.log | head -n 1)
tail -n 35 "$LATEST"
BASE="${LATEST%.controller.log}"
if [ -f "${BASE}.exit" ]; then
  echo "Controller exit:"; cat "${BASE}.exit"
else
  echo "No exit file yet: check process identity; absence is not proof of success"
fi
nvidia-smi
```

Per-job logs live under `logs/mnist_stage22_s10_multiseed_v1/`. Controller logs record `SEED s BOTH GPU LANES COMPLETE` before advancing to `SEED s+1`. A nonzero `.exit` means failure. If no `.exit` exists and the PID is gone, investigate; do not assume success.

### 4) Incremental results: seed 0 through seed 5

**Safe to run while seeds 6–9 are still running:**

```bash
cd ~/DungNDH/micl/bayesfl
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" -B scripts/mnist_stage22_s10_multiseed.py summary --through 5
```

Outputs:

- `reports/mnist_stage22_s10_multiseed_v1/summary_through_seed5.md`
- `reports/mnist_stage22_s10_multiseed_v1/summary_through_seed5.csv`
- `reports/mnist_stage22_s10_multiseed_v1/summary_through_seed5_per_seed.csv`
- `reports/mnist_stage22_s10_multiseed_v1/summary_through_seed5.json`

Only **fully completed seed pairs** (all eight methods) from the contiguous prefix `0..N` are included; incomplete runs are listed but not counted in means or SD. Each method's endpoint is chosen at the *matching communication budget*, not the same round count. With one completed seed, SD is `N/A`.

The controller additionally creates a snapshot automatically after each fully completed seed, so `summary_through_seed5.md` will already exist after seed 5 finishes.

### 5) Final summary

```bash
"$PY" -B scripts/mnist_stage22_s10_multiseed.py summary --through 9
```

## Safe restart / failure policy

- Existing **complete, validated** run directories are skipped without training.
- An existing **partial, invalid, duplicated, or unverified** run stops the controller. No automatic resume, overwrite, deletion or restart.
- To continue after a failure, inspect the failed job/log and agree on a safe checkpoint-resume process; do not simply rerun the `run` command over partial directories.
- The controller lock prevents two copies of this coordinator from starting at the same time.
- Seeds are partitioned deterministically; the 9 partitions are cached before the parallel phase to avoid cache races.
- Check both GPUs' memory and other running training processes before launch. Simultaneous Flower/Ray processes may require system-specific resource tuning; this procedure has not been validated on your live host.

## Verification performed before delivery

- Inspected original `bayesfl.zip` Stage-18/22/23 templates and Stage-22 plotting/communication accounting.
- Generated all 72 new configuration files in a temporary extracted archive and validated them through the existing schema.
- Verified per-seed FOLA/FedAvg matching initial states.
- Cross-checked historic seed-0 outputs; reports the correct 89.44% FOLA and 88.23% clipped FedAvg at R150/R300.
- Exercised incremental summary with missing seeds, and a mocked two-lane scheduling test proved there is a barrier between seeds.
- **No real training was launched.**
