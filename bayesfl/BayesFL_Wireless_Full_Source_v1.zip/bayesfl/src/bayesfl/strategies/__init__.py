"""Flower server strategies."""
