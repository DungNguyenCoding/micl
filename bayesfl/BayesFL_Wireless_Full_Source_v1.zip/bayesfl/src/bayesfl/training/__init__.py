"""Local training algorithms."""
