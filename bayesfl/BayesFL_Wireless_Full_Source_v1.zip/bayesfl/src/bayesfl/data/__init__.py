"""Dataset and partition helpers."""
