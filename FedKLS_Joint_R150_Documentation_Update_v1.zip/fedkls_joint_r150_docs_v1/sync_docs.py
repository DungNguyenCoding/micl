#!/usr/bin/env python3
"""Guarded add-only 2026-11-10 joint-only R150 documentation sync."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

PACKAGE=Path(__file__).resolve().parent
MARKER='JOINT_FEDKLS_CIFAR10_R150_VERIFIED_20261110'
START=f'<!-- BEGIN {MARKER} -->'
END=f'<!-- END {MARKER} -->'
TARGETS=[
  'docs/CHAT_HANDOFF.md',
  'docs/wireless/STATUS.md',
  'docs/wireless/VALIDATION.md',
  'docs/wireless/README.md',
]
OPTIONAL=['docs/RUN_REGISTRY.md']
SINGLE="""\n{start}\n### 2026-11-10 — Joint-only CIFAR-10 R150 audit (supersedes earlier pending CIFAR/Flower statuses)\n\n- **Primary research method:** FedKLS joint KL-guided bandwidth and integer coordinate retention. Equal bandwidth is a historical engineering pilot, **not the focus** of the current research.\n- **Verified run:** `run_wireless_cifar_eqb_joint150_fixed_v1_cifar10_a0p01_f1_joint_seed0_20261109_230207`; **R150 accuracy 52.63%**, NLL 1.40449; best 52.76% at R148; final-20-round mean 52.1115%.\n- **Source audit:** `PASS_ENGINEERING_RECORD_INTEGRITY`; 150 rounds, 3,000 client-round rows, 5,579 price queries, 11,438,601,248 model-array bytes and 111,770,677 control bytes. All 161 included exported-evidence hashes independently verified.\n- **Limits:** One CIFAR-10 seed 0 and fixed wireless path-loss scenario; no globally certified integer solution; power/control/compute times remain modeled, not physical measurements; no independent checkpoint-tensor examination.\n- **Evidence & detailed findings:** [CIFAR-10 Joint R150 Review]({link}) (includes control breakdown, retention, learning curves and normalized KL contribution correction).\n- **Derived audit caveat:** Previously generated per-client `weighted_discarded_kl` audit CSV contains `n_k*tail` rather than `(n_k/N)*tail`; the production round objective is correct. Use the corrected per-client CSV included in the R150 review package.\n\n{end}\n"""


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def append_text(path, text):
    original=path.read_text(encoding='utf-8')
    if START in original or END in original:
        if original.count(START)!=1 or original.count(END)!=1:
            raise RuntimeError(f'Inconsistent marker in {path}')
        old=original[original.index(START):original.index(END)+len(END)]
        new=text[text.index(START):text.index(END)+len(END)]
        if old!=new:
            raise RuntimeError(f'Conflicting existing R150 section in {path}; refusing overwrite')
        return None
    return original.rstrip('\n')+'\n\n'+text.lstrip('\n')


def safe_write(p,text):
    fd,n=tempfile.mkstemp(prefix=p.name+'.tmp.',dir=str(p.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f:
            f.write(text)
        os.chmod(n,p.stat().st_mode & 0o777)
        os.replace(n,p)
    finally:
        if os.path.exists(n): os.remove(n)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,required=True)
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--preview',action='store_true')
    group.add_argument('--apply',action='store_true')
    group.add_argument('--verify',action='store_true')
    ap.add_argument('--confirm',default='')
    args=ap.parse_args()
    root=args.root.expanduser().resolve()
    if not (root/'docs/CHAT_HANDOFF.md').is_file() or not (root/'src/bayesfl/wireless/allocation.py').is_file():
        raise SystemExit('STOP: --root is not the installed wireless BayesFL repository')
    manifest=json.loads((PACKAGE/'MANIFEST.json').read_text())
    payload=PACKAGE/'payload'
    for rel, h in manifest['payload_sha256'].items():
        p=payload/rel
        if not p.is_file() or digest(p)!=h:
            raise SystemExit(f'STOP: package integrity failure {rel}')
    additions=[]
    for rel in manifest['payload_sha256']:
        src=payload/rel
        dst=root/rel
        if dst.exists():
            if not dst.is_file() or digest(dst)!=digest(src):
                raise SystemExit(f'STOP: existing destination differs: {dst}')
        else:
            additions.append((src,dst))
    updates=[]
    for rel in TARGETS+OPTIONAL:
        target=root/rel
        if rel in OPTIONAL and not target.is_file():
            print(f'SKIP OPTIONAL NOT FOUND: {rel}')
            continue
        if not target.is_file():
            raise SystemExit(f'STOP: required canonical document missing: {rel}')
        link=('r150_joint_20261110/JOINT_R150_REVIEW.md' if rel.startswith('docs/wireless/') else 'wireless/r150_joint_20261110/JOINT_R150_REVIEW.md')
        block=SINGLE.format(start=START,end=END,link=link)
        new=append_text(target,block)
        if new is not None:updates.append((target,new))
    print(f'Plan: ADD {len(additions)} | APPEND_BACKED_UP {len(updates)}')
    for _,dst in additions:print('ADD',dst.relative_to(root))
    for dst,_ in updates:print('APPEND_BACKED_UP',dst.relative_to(root))
    if args.preview:
        print('PASS: PREVIEW ONLY; repository unchanged')
        return
    if args.verify:
        if additions or updates:raise SystemExit('STOP: Not installed/completely synchronized')
        print('PASS: JOINT R150 DOCUMENTATION VERIFIED')
        return
    if args.confirm!='INSTALL_JOINT_R150_DOCS_V1':
        raise SystemExit('STOP: --apply requires --confirm INSTALL_JOINT_R150_DOCS_V1')
    if not additions and not updates:
        print('PASS: ALREADY INSTALLED; NO CHANGE')
        return
    backup=root.parent/('bayesfl_joint_r150_docs_backup_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    backup.mkdir(parents=True,exist_ok=False)
    for target,_ in updates:
        save=backup/target.relative_to(root)
        save.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(target,save)
    for src,dst in additions:
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)
        if digest(src)!=digest(dst):raise RuntimeError(f'Installed hash failed: {dst}')
    for target,text in updates:
        safe_write(target,text)
    (backup/'RECEIPT.txt').write_text('R150 docs append backups; restorable originals under relative paths.\n')
    print('BACKUP:',backup)
    print('PASS: JOINT R150 DOCUMENTATION INSTALLED')

if __name__=='__main__':
    main()
