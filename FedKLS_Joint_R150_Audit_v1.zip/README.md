# FedKLS joint-only CIFAR-10 R150 audit v1

**Purpose:** Verify the existing joint KL wireless run's internal learning/resource accounting, without training, modifying source, touching baseline outputs, or using equal-bandwidth as the main method.

## Install without replacements

Place `FedKLS_Joint_R150_Audit_v1.zip` in `~/DungNDH/micl/`, then:

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
for f in scripts/audit_joint_wireless_run_v1.py docs/wireless/JOINT_R150_AUDIT_RUNBOOK_v1.md; do
    if [ -e "$f" ]; then echo "STOP: existing file $f"; exit 1; fi
done
unzip -n ../FedKLS_Joint_R150_Audit_v1.zip
```

## Run

```bash
cd ~/DungNDH/micl/bayesfl || exit 1
PY=/home/micl/anaconda3/envs/dungndh/bin/python
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"
"$PY" scripts/audit_joint_wireless_run_v1.py --root "$PWD" --tag cifar_eqb_joint150_fixed_v1 --rounds 150
```

Run from the BayesFL repository directory. It auto-discovers the joint job in the study manifest and requires exactly one matching output. If multiple runs exist, explicitly pass `--run-dir /absolute/path/to/the/joint/output` to disambiguate. It validates read-only source records and writes an evidence ZIP under `~/DungNDH/micl/`.

This script was rehearsal-tested on the earlier **real joint R20 diagnostic archive**, passing the complete audit; a deliberately tampered client keep count was rejected. The actual R150 source files have **not** been examined here, so a server PASS is required before concluding the full trajectory is internally consistent.

No modifications to existing BayesFL `src/`, tests, datasets, checkpoints, queues, or prior results. The package's `docs/wireless/JOINT_R150_AUDIT_RUNBOOK_v1.md` is an additive runbook; canonical `docs/CHAT_HANDOFF.md` and registries remain unchanged until reviewed separately.
