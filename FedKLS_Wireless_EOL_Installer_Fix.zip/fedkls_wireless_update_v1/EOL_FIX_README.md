# Wireless v1 installer: LF/CRLF-safe variant

This file is a separate installer for the already extracted `FedKLS_Wireless_Update_v1.zip`.
It must be placed beside the existing `MANIFEST.json`, `payload/`, and `install_wireless.py` in
`~/DungNDH/micl/fedkls_wireless_update_v1/`.

It accepts a file only if it has its original SHA-256 or if changing **only** line terminators
(LF versus CRLF) makes its SHA-256 equal one of the explicitly approved manifest values.
Any actual content difference, missing source file, or unexpected installed target is rejected.
All original backup, per-file verification, and no-force protections remain.

From `~/DungNDH/micl`:

```bash
PY=/home/micl/anaconda3/envs/dungndh/bin/python
"$PY" fedkls_wireless_update_v1/install_wireless_eol_safe.py --root "$PWD/bayesfl" --preview
# Only after a full PASS and review:
"$PY" fedkls_wireless_update_v1/install_wireless_eol_safe.py --root "$PWD/bayesfl" --apply --confirm INSTALL_FEDKLS_WIRELESS_V1
"$PY" fedkls_wireless_update_v1/install_wireless_eol_safe.py --root "$PWD/bayesfl" --verify
```

No changes to `requirements.txt`, `pyproject.toml` or other baseline files are needed for line-ending mismatches.
The original installer remains available unchanged. If the preview identifies a real content conflict,
stop and review that source. Do not force an overwrite.

Tested against a temporary repository derived from `baseline_src.zip`: preview/apply/verify passed
with LF normalized copies of all 39 baseline guards and 29 existing install targets. True content
changes in a guard and an install target were both refused. This is not a test of your live server.
