# INSTALLER PATCH: LF/CRLF-only hash compatibility (2026-11-09).
# This file is a drop-in replacement for the v1 wireless update installer.
# It retains all existing manifest, backup, no-force, and rollback checks.
#!/usr/bin/env python3
"""Verified source/docs overlay; never installs outputs, datasets, dependencies or Git history."""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

HERE=Path(__file__).resolve().parent
TOKEN='INSTALL_FEDKLS_WIRELESS_V1'
FORBIDDEN={'outputs','data','plots','logs','.git','backups','modified_source'}
ROOT_ALLOWED={'README.md','AGENTS.md','SPARSE_README.md','IMPLEMENTATION_REPORT.md',
              'VALIDATION.md','VALIDATION_SPARSE.md','WIRELESS_IMPLEMENTATION_REPORT.md',
              'WIRELESS_CHANGE_MANIFEST.json'}


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def safe(root,relative):
    rel=Path(relative)
    if rel.is_absolute() or not rel.parts or '..' in rel.parts or '.' in rel.parts:
        raise ValueError(f'Unsafe relative path: {relative}')
    p=root
    for part in rel.parts:
        p=p/part
        if p.is_symlink():raise ValueError(f'Refusing symbolic-link path: {p}')
    return p


def target_allowed(path):
    p=Path(path)
    if p.parts[0] in FORBIDDEN:return False
    if len(p.parts)==1:return path in ROOT_ALLOWED
    return p.parts[0] in {'src','scripts','tests','docs','validation'}


# Line-ending-only compatibility: preserve the meaning of the original SHA-256
# manifest without treating LF/CRLF differences as source-code edits.
# No content changes, whitespace changes, encoding changes, or missing files
# are permitted by this exception.
_TEXT_SUFFIXES = {".py", ".md", ".txt", ".toml", ".json", ".yaml", ".yml", ".tex", ".sh", ".csv"}


def _line_ending_equivalent(path, expected_hashes):
    if path.suffix.lower() not in _TEXT_SUFFIXES:
        return False
    raw = path.read_bytes()
    if b"\x00" in raw:
        return False
    lf = raw.replace(b"\r\n", b"\n")
    if b"\r" in lf:  # refuse unusual/mixed bare-CR conventions
        return False
    lf_hash = hashlib.sha256(lf).hexdigest()
    crlf_hash = hashlib.sha256(lf.replace(b"\n", b"\r\n")).hexdigest()
    return any(h in expected_hashes for h in (lf_hash, crlf_hash))


def guard_snapshot(root,manifest):
    result={}
    for relative,expected in manifest['compatibility_guards'].items():
        p=safe(root,relative)
        if not p.is_file() or (sha(p)!=expected and not _line_ending_equivalent(p, {expected})):
            raise ValueError(f'Baseline compatibility guard differs: {relative}. Stop and compare the newer source; do not force overwrite.')
        result[relative]=sha(p)  # actual bytes verified, including LF/CRLF variant
    return result


def read_plan(root,manifest):
    seen=set();plan=[]
    for item in manifest['files']:
        relative=item['path']
        if relative in seen or not target_allowed(relative):raise ValueError(f'Forbidden/duplicate target: {relative}')
        seen.add(relative)
        source=safe(HERE/'payload',relative)
        if not source.is_file() or sha(source)!=item['sha256'] or source.stat().st_size!=item['bytes']:
            raise ValueError(f'Package integrity check failed: {relative}')
        dest=safe(root,relative)
        if dest.exists() and not dest.is_file():raise ValueError(f'Target is not a regular file: {dest}')
        before=sha(dest) if dest.exists() else None
        if before==item['sha256']:status='IDENTICAL'
        elif before is None:
            if item.get('requires_existing',False):raise ValueError(f'Expected original file is missing: {relative}')
            status='ADD'
        elif (before in item['accepted_before_sha256']
              or _line_ending_equivalent(dest, set(item['accepted_before_sha256']) | {item['sha256']})):
            # Canonical package bytes will replace an approved LF/CRLF variant,
            # after the installer's normal verified backup step.
            status='REPLACE_BACKED_UP'
        else:raise ValueError(f'Unreviewed local modification/conflict: {relative}. No files installed. Preserve this file and compare; there is no force mode.')
        plan.append(dict(item,status=status,before_sha256=before))
    return plan


def atomic_copy(source,dest):
    dest.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.'+dest.name+'.wireless-',dir=dest.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            with Path(source).open('rb') as inp:shutil.copyfileobj(inp,f)
            f.flush();os.fsync(f.fileno())
        shutil.copymode(source,tmp)
        os.replace(tmp,dest)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--preview',action='store_true');group.add_argument('--apply',action='store_true');group.add_argument('--verify',action='store_true')
    p.add_argument('--confirm');a=p.parse_args()
    # Resolve parent ancestry, but never silently write through a user-specified root symlink.
    root=a.root.expanduser().absolute()
    for part in [root,*root.parents]:
        if part.is_symlink():raise ValueError(f'Repository path includes a symlink: {part}')
    root=root.resolve()
    if not (root/'src/bayesfl/main.py').is_file() or not (root/'pyproject.toml').is_file():
        raise ValueError('Root is not the supplied BayesFL repository')
    if root==HERE or root in HERE.parents:raise ValueError('Extract the installer BESIDE the repository, not inside it')
    manifest=json.loads((HERE/'MANIFEST.json').read_text())
    guards=guard_snapshot(root,manifest)
    plan=read_plan(root,manifest)
    for row in plan:print(f"{row['status']:<20} {row['path']}")
    counts={k:sum(r['status']==k for r in plan) for k in ('ADD','REPLACE_BACKED_UP','IDENTICAL')}
    print('\nPlan:',counts,'| baseline guards:',len(guards))
    if a.preview:
        print('PASS: PREVIEW ONLY; no repository file or directory created.');return
    if a.verify:
        if any(r['status']!='IDENTICAL' for r in plan):raise ValueError('Release files are not all installed identically')
        print('PASS: WIRELESS SOURCE/DOCS HASH VERIFICATION COMPLETE');return
    if a.confirm!=TOKEN:raise ValueError(f'Apply requires --confirm {TOKEN}')
    selected=[r for r in plan if r['status']!='IDENTICAL']
    if not selected:print('PASS: Already installed; no files changed.');return
    # Finish all source/conflict checks before creating the backup or modifying any target.
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=root.parent/('bayesfl_wireless_backup_'+stamp)
    backup.mkdir(exist_ok=False)
    receipt={'release':manifest['release'],'root':str(root),'created_at':datetime.now().astimezone().isoformat(),
             'status':'in_progress','written':[],'planned':selected,'guards':guards}
    receipt_path=backup/'INSTALL_RECEIPT.json'
    def save_receipt():
        tmp=receipt_path.with_suffix('.tmp');tmp.write_text(json.dumps(receipt,indent=2)+'\n');os.replace(tmp,receipt_path)
    save_receipt()
    for row in selected:
        if row['before_sha256'] is not None:
            dst=safe(backup/'previous',row['path']);dst.parent.mkdir(parents=True,exist_ok=True)
            src=safe(root,row['path']);shutil.copy2(src,dst)
            if sha(dst)!=row['before_sha256']:raise ValueError('Backup verification failed')
    guard_snapshot(root,manifest)
    # Per-file concurrent-change guards; stop all source writers before installation.
    for row in selected:
        dest=safe(root,row['path']);now=sha(dest) if dest.exists() else None
        if now!=row['before_sha256']:raise ValueError(f"Target changed during installation: {row['path']}")
        atomic_copy(safe(HERE/'payload',row['path']),dest)
        if sha(dest)!=row['sha256']:raise ValueError(f"Installed hash mismatch: {row['path']}")
        receipt['written'].append(row['path']);save_receipt()
    guard_snapshot(root,manifest)
    for row in plan:
        if sha(safe(root,row['path']))!=row['sha256']:raise ValueError(f"Verification failed: {row['path']}")
    receipt['status']='complete';save_receipt()
    print('\nPASS: WIRELESS SOURCE/DOCS INSTALLED AND VERIFIED')
    print('Verified backup:',backup)
    print('No output, dataset, partition, dependency, .gitignore or existing legacy queue/plot file installed.')
    print('This is per-file verified installation, not an all-files atomic transaction. Keep the receipt/backup.')

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as exc:
        print('ERROR:',exc,file=sys.stderr);raise SystemExit(1)
